package domain;

import java.io.Serializable;

public interface AIProfile extends Serializable {
    String ACTION_IDLE = "IDLE";
    String ACTION_MOVE_LEFT = "LEFT";
    String ACTION_MOVE_RIGHT = "RIGHT";
    String ACTION_JUMP = "JUMP";
    String ACTION_KICK = "KICK";
    String ACTION_POWER = "POWER";
    String decideAction(Player aiPlayer, Player opponent, Ball ball);
}