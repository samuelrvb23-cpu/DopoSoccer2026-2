package domain;

import java.io.Serializable;

/**
 * Mantiene y calcula las 4 estadísticas de un jugador (Speed, Jump, Kick y Survival).
 * Todas inician en 1 y suben hasta 10 (+10% por cada punto sobre 1).
 */
public class Statistics implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final int MIN_LEVEL = 1;
    public static final int MAX_LEVEL = 10;
    public static final int BASE_UPGRADE_COST = 500;

    private int speed;
    private int jump;
    private int kick;
    private int survival;

    public Statistics() {
        this.speed = MIN_LEVEL;
        this.jump = MIN_LEVEL;
        this.kick = MIN_LEVEL;
        this.survival = MIN_LEVEL;
    }

    /**
     * multiplicadorKick = 1 + 0.10 * (Kick - 1) 
     */
    public double getKickMultiplier() {
        return 1.0 + 0.10 * (this.kick - 1);
    }

    /**
     * vidaMax = 100 * (1 + 0.10 * (Survival - 1)) 
     */
    public double getMaxHealth() {
        return 100.0 * (1.0 + 0.10 * (this.survival - 1));
    }

    public double getMaxLife() {
        return getMaxHealth();
    }

    /**
     * Incremento del 10% por cada nivel sobre 1 para velocidad de desplazamiento.
     */
    public double getSpeedMultiplier() {
        return 1.0 + 0.10 * (this.speed - 1);
    }

    /**
     * Incremento del 10% por cada nivel sobre 1 para altura de salto.
     */
    public double getJumpMultiplier() {
        return 1.0 + 0.10 * (this.jump - 1);
    }

    /**
     * Precio duplicado por nivel empezando en 500 (500, 1000, 2000, 4000...).
     */
    public int getUpgradeCost(int currentLevel) {
        return BASE_UPGRADE_COST * (1 << (currentLevel - 1));
    }

    public boolean upgradeSpeed() {
        boolean upgraded = false;
        if (speed < MAX_LEVEL) {
            speed++;
            upgraded = true;
        }
        return upgraded;
    }

    public boolean upgradeJump() {
        boolean upgraded = false;
        if (jump < MAX_LEVEL) {
            jump++;
            upgraded = true;
        }
        return upgraded;
    }

    public boolean upgradeKick() {
        boolean upgraded = false;
        if (kick < MAX_LEVEL) {
            kick++;
            upgraded = true;
        }
        return upgraded;
    }

    public boolean upgradeSurvival() {
        boolean upgraded = false;
        if (survival < MAX_LEVEL) {
            survival++;
            upgraded = true;
        }
        return upgraded;
    }

    public int getSpeed() { return speed; }
    public int getJump() { return jump; }
    public int getKick() { return kick; }
    public int getSurvival() { return survival; }
}