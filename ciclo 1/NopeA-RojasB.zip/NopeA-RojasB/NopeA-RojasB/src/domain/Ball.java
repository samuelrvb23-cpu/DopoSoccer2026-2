package domain;

import java.io.Serializable;

public class Ball implements Serializable {
    private static final long serialVersionUID = 1L;


    public static final double GRAVITY = 0.45;
    public static final double AIR_FRICTION = 0.99;
    public static final double BOUNCE_DAMPING = 0.75;
    public static final double RADIUS = 14.0;

    private double posX, posY;
    private double velX, velY;

    private boolean isFake; // Para el poder Ilusión de Estados Unidos balones falsos
    private Character activePowerShot; // Referencia al poder que lleva el balón 
    private Player lastShooter;
    
    public Ball(double startX, double startY) {
        this(startX,startY,false);
    }
    public Ball(double startX, double startY, boolean isFake) {
        this.posX = startX;
        this.posY = startY;
        this.velX = 0;
        this.velY = 0;
        this.isFake = isFake;
        this.activePowerShot = null;
        this.lastShooter = null;
    }
    public void updatePhysics() {
        posX += velX;
        posY += velY;
        velY += GRAVITY;
        velX *= AIR_FRICTION;
    }
    public void bounceVertical(double limitY) {
        this.posY = limitY;
        this.velY = -this.velY * BOUNCE_DAMPING;
    }

    /**
     * Rebota horizontalmente contra los bordes o travesaños.
     */
    public void bounceHorizontal(double limitX) {
        this.posX = limitX;
        this.velX = -this.velX * 0.80;
    }

    /**
     * Reinicia el balón en el centro de la cancha después de un gol 
     */
    public void resetPosition(double centerX, double centerY) {
        this.posX = centerX;
        this.posY = centerY;
        this.velX = 0;
        this.velY = 0;
        clearPowerShot();
    }

    public void activatePowerShot(Character power, Player shooter) {
        this.activePowerShot = power;
        this.lastShooter = shooter;
    }

    public void clearPowerShot() {
        this.activePowerShot = null;
        this.lastShooter = null;
    }

    public boolean hasActivePowerShot() {
        return activePowerShot != null;
    }

    
    public double getPosX() { return posX; }
    public double getPosY() { return posY; }
    public void setPosX(double posX) { this.posX = posX; }
    public void setPosY(double posY) { this.posY = posY; }
    public double getVelX() { return velX; }
    public void setVelX(double velX) { this.velX = velX; }
    public double getVelY() { return velY; }
    public void setVelY(double velY) { this.velY = velY; }
    public boolean isFake() { return isFake; }
    public Character getActivePowerShot() { return activePowerShot; }
    public Player getLastShooter() { return lastShooter; }
}