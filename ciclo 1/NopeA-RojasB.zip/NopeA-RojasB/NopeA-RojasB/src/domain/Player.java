package domain;

import java.io.Serializable;

/**
 * Representa a un jugador dentro del partido.
 * Mantiene su personaje, goles, vida actual, barra de poder, aura, estadísticas, puntos y efectos.
 */
public class Player implements Serializable {
    private static final long serialVersionUID = 1L;

    // Constantes oficiales del PDF DOPOSoccer
    public static final double BASE_KICK_DAMAGE = 10.0; //  Patada normal = 10 * multiplicador
    public static final double BALL_KICK_SPEED_X = 14.0; // La estadística Kick NO cambia la fuerza del balón
    public static final double BALL_KICK_SPEED_Y = -9.0;
    public static final int STUN_DURATION_FRAMES = 180; // 3 segundos 

    // Tipos de efecto de poder (Regla 8: un nuevo efecto reemplaza al anterior, no se acumulan)
    public static final String EFFECT_NONE = "NONE";
    public static final String EFFECT_PUSHED = "PUSHED";           // Corea del Sur (1.5s)
    public static final String EFFECT_ELECTROCUTED = "ELECTROCUTED"; // Camerún (3.0s)
    public static final String EFFECT_UNCONSCIOUS = "UNCONSCIOUS";   // Nigeria (3.0s)
    public static final String EFFECT_CONFUSED = "CONFUSED";         // Estados Unidos (2.5s)

    private double posX, posY;
    private boolean isFacingRight;
    private boolean isKicking;
    private int kickTimer;

    private Statistics stats;
    private Character character;

    // Información obligatoria del jugador 
    private int goals;
    private double currentLife;
    private double powerBar;       // 0.0 a 100.0 (se llena en 10s; +25% al recibir gol)
    private boolean hasActiveAura; // Regla 3: Aura activa sin límite de tiempo hasta tocar el balón
    private int points;            // Puntos acumulados (+100 ganador, +25 perdedor)

    // Control de Aturdimiento (cuando la vida llega a 0) y Efectos de Poder
    private boolean isStunned;
    private int stunTimerFrames;
    private String activeEffect;
    private int effectTimerFrames;

    public Player(double startX, double startY, boolean isFacingRight, Statistics stats, Character character) {
        this.posX = startX;
        this.posY = startY;
        this.isFacingRight = isFacingRight;
        this.stats = (stats != null) ? stats : new Statistics();
        this.character = character;
        this.points = 0;
        resetForNewMatch();
    }

    /**
     * Reinicia el estado del jugador al inicio del partido osea Marcador 0, barra vacía, vida al máximo
     */
    public final void resetForNewMatch() {
        this.goals = 0;
        this.currentLife = stats.getMaxLife(); // Anexo 2: 100 * (1 + 0.10 * (Survival - 1))
        this.powerBar = 0.0;
        this.hasActiveAura = false;
        this.isKicking = false;
        this.kickTimer = 0;
        this.isStunned = false;
        this.stunTimerFrames = 0;
        this.activeEffect = EFFECT_NONE;
        this.effectTimerFrames = 0;
    }

    /**
     * Delega en el método completo pasando opponent como null para no repetir lógica
     */
    public void Kick(Ball ball){
        kick(ball,null);
    }
    /**
     * Ejecuta la patada sobre el balón o sobre el rival si está al alcance
     */
    public void kick(Ball ball, Player opponent) {
        if (canAct()) {
            this.isKicking = true;
            this.kickTimer = 15;

            if (ball != null) {
                double distBall = Math.hypot(this.posX - ball.getPosX(), this.posY - ball.getPosY());
                if (distBall <= 65.0) {
                    if (hasActiveAura && character != null) {
                        character.triggerPowerShot(this, opponent, ball);
                    } else {
                        double forceX = isFacingRight ? BALL_KICK_SPEED_X : -BALL_KICK_SPEED_X;
                        ball.setVelX(forceX);
                        ball.setVelY(BALL_KICK_SPEED_Y);
                    }
                }
            }

            if (opponent != null) {
                double distOpponent = Math.hypot(this.posX - opponent.getPosX(), this.posY - opponent.getPosY());
                if (distOpponent <= 65.0) {
                    double kickDamage = BASE_KICK_DAMAGE * stats.getKickMultiplier();
                    opponent.receiveDamage(kickDamage);
                }
            }
        }
    }

    /**
     * Reglas 2, 3 y 7 del PDF: Activa el aura si la barra está llena  y no tiene ya un aura activa.
     */
    public boolean activatePower() {
        if (!canAct() || hasActiveAura || powerBar < 100.0) {
            return false;
        }
        this.powerBar = 0.0; // Se vacía y empieza a recargarse de inmediato
        this.hasActiveAura = true;
        return true;
    }

    public void consumePowerAura() {
        this.hasActiveAura = false;
    }

    /**
     * Regla 1 de Poderes: La barra se llena en 10s (+10% por segundo) y sube +25% al recibir gol
     */
    public void chargePowerBar(double amount) {
        this.powerBar = Math.min(100.0, Math.max(0.0, this.powerBar + amount));
    }

    public void onGoalConceded() {
        chargePowerBar(25.0); // Aumenta 1/4 inmediatamente al recibir un gol
    }

    /**
     *
     * Actualiza VidaActual - Daño (mínimo 0). Si llega a 0, queda aturdido durante 3 segundos.
     */
    public void receiveDamage(double amount) {
        if (amount > 0 && !isStunned) {
            this.currentLife = Math.max(0.0, this.currentLife - amount);
            if (this.currentLife == 0.0) {
                this.isStunned = true;
                this.stunTimerFrames = STUN_DURATION_FRAMES;
            }
        }
    }

    /**
     * Actualiza temporizadores por frame: animación de patada, aturdimiento y efectos de poder.
     */
    public void update() {
        if (kickTimer > 0) {
            kickTimer--;
            if (kickTimer == 0) {
                isKicking = false;
            }
        }

        // Aturdimiento: Al terminar los 3s, su vida se reinicia a su vida máxima
        if (isStunned && stunTimerFrames > 0) {
            stunTimerFrames--;
            if (stunTimerFrames == 0) {
                isStunned = false;
                this.currentLife = stats.getMaxLife();
            }
        }

        // Duración del efecto de tiro de poder activo
        if (effectTimerFrames > 0) {
            effectTimerFrames--;
            if (effectTimerFrames == 0) {
                activeEffect = EFFECT_NONE;
            }
        }
    }

    //  EFECTOS DE TIROS DE PODER segun Regla 8: el nuevo efecto reemplaza al anterior) 

    public void pushBack(double amount) {
        this.posX += amount;
        setEffect(EFFECT_PUSHED, 1.5);
    }

    public void applyElectrocutedEffect(double durationSeconds) {
        setEffect(EFFECT_ELECTROCUTED, durationSeconds);
    }

    public void applyUnconsciousEffect(double durationSeconds) {
        setEffect(EFFECT_UNCONSCIOUS, durationSeconds);
    }

    public void applyConfusionEffect(double durationSeconds) {
        setEffect(EFFECT_CONFUSED, durationSeconds);
    }

    private void setEffect(String effectType, double durationSeconds) {
        this.activeEffect = effectType;
        this.effectTimerFrames = (int) Math.round(durationSeconds * 60);
    }

    /**
     * Indica si el jugador puede moverse, saltar o patear en este instante.
     */
    public boolean canAct() {
        return !isStunned && !EFFECT_UNCONSCIOUS.equals(activeEffect);
    }

    /**
     * Indica si el jugador puede saltar osea Electrocutado de Camerún impide saltar.
     */
    public boolean canJump() {
        return canAct() && !EFFECT_ELECTROCUTED.equals(activeEffect);
    }

    /**
     * Devuelve el factor de velocidad actual, 50% si está electrocutado por Camerún, 0% si no puede actuar
     */
    public double getCurrentSpeedFactor() {
        if (!canAct()) return 0.0;
        if (EFFECT_ELECTROCUTED.equals(activeEffect)) return 0.5;
        return 1.0;
    }

    public void scoreGoal() {
        this.goals++;
    }

    public void addMatchPoints(boolean won) {
        this.points += won ? 100 : 25;
    }

    
    public double getPosX() { return posX; }
    public double getPosY() { return posY; }
    public void setPosX(double posX) { this.posX = posX; }
    public void setPosY(double posY) { this.posY = posY; }
    public boolean isFacingRight() { return isFacingRight; }
    public boolean isKicking() { return isKicking; }
    public Statistics getStats() { return stats; }
    public Character getCharacter() { return character; }
    public void setCharacter(Character character) { this.character = character; }
    public double getPowerBar() { return powerBar; }
    public void setPowerBar(double powerBar) { this.powerBar = Math.min(100.0, Math.max(0.0, powerBar)); }
    public double getCurrentLife() { return currentLife; }
    public boolean isStunned() { return isStunned; }
    public boolean hasActiveAura() { return hasActiveAura; }
    public String getActiveEffect() { return activeEffect; }
    public int getGoals() { return goals; }
    public int getPoints() { return points; }
}