package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

/**
 * Ventana principal de DOPOSoccer.
 */
public class DOPOSoccerGUI extends JFrame {

    
    public static final String MENU_VIEW = "MENU";
    public static final String CONFIG_VIEW = "CONFIG";
    public static final String GAME_VIEW = "GAME";

    // Contenedor principal y paneles de cada pantalla
    private CardLayout cardLayout;
    private JPanel mainContainer;
    private MenuPanel menuPanel;
    private ConfigPanel configPanel;
    private GamePanel gamePanel;

    // Componentes de menú 
    private JMenuItem itemNewGame;
    private JMenuItem itemOpen;
    private JMenuItem itemSave;
    // PATRÓN SINGLETON
    private static DOPOSoccerGUI instance = null;
    private static java.net.ServerSocket singleInstanceLock;
    // para una sola instancia
    private  DOPOSoccerGUI() {
        prepareView();
        prepareController();
    }
    public static DOPOSoccerGUI getInstance() {
        if (instance == null) {
            instance = new DOPOSoccerGUI();
        }
        return instance;
    }
    /**
     * inicializa y organiza los componentes gráficos.
     */
    private void prepareView() {
        setTitle("DOPOSoccer 2026-2 - Escuela Colombiana de Ingeniería");
        setSize(1024, 640); // Resolución media por defecto
        setResizable(false);
        setLocationRelativeTo(null); // Centrar en pantalla

        prepareMenuBar();

        cardLayout = new CardLayout();
        mainContainer = new JPanel(cardLayout);

        menuPanel = new MenuPanel(this);
        configPanel = new ConfigPanel(this);
        gamePanel = new GamePanel(this);

        mainContainer.add(menuPanel, MENU_VIEW);
        mainContainer.add(configPanel, CONFIG_VIEW);
        mainContainer.add(gamePanel, GAME_VIEW);

        add(mainContainer, BorderLayout.CENTER);
    }

    private void prepareMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("Archivo");

        itemNewGame = new JMenuItem("Nuevo Partido");
        itemOpen = new JMenuItem("Abrir Partida...");
        itemSave = new JMenuItem("Salvar Partida...");
        

        fileMenu.add(itemNewGame);
        fileMenu.addSeparator();
        fileMenu.add(itemOpen);
        fileMenu.add(itemSave);

        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }

 
    private void prepareController() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitApplicationAction();
            }
        });

        itemNewGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showScreen(CONFIG_VIEW);
            }
        });

        itemOpen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openFileAction();
            }
        });

        itemSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveFileAction();
            }
        });
    }

    /**
     * Cambia entre las pantallas de la aplicación
     */
    public void showScreen(String screenName) {
        if (!GAME_VIEW.equals(screenName)) {
            gamePanel.stopMatchLoop();
        }
        cardLayout.show(mainContainer, screenName);
        if (GAME_VIEW.equals(screenName)) {
            gamePanel.requestFocusInWindow();
        }
    }

    /**
     * Inicia el partido aplicando la configuración elegida y ajustando la resolución.
     */
    public void startConfiguredMatch(String mode, String p1Country, String p2Country,
                                     boolean isByTime, int targetValue, Dimension resolution) {
        setSize(resolution);
        setLocationRelativeTo(null);
        gamePanel.setupMatch(mode, p1Country, p2Country, isByTime, targetValue);
        showScreen(GAME_VIEW);
    }

    /**
     * Abre el diálogo JFileChooser para cargar una partida.
     */
    public void openFileAction() {
        JFileChooser fileChooser = new JFileChooser();
        int option = fileChooser.showOpenDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            JOptionPane.showMessageDialog(this,
                    "Archivo seleccionado para abrir: " + file.getName() + "\n(Se conectará con Persistencia en Versión 2)",
                    "Abrir Partida", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Abre el diálogo JFileChooser para guardar una partida.
     */
    public void saveFileAction() {
        JFileChooser fileChooser = new JFileChooser();
        int option = fileChooser.showSaveDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            JOptionPane.showMessageDialog(this,
                    "Partida guardada en: " + file.getName() + "\n(Se conectará con Persistencia en Versión 2)",
                    "Salvar Partida", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Confirma la salida de la aplicación con JOptionPane.
     */
    public void exitApplicationAction() {
        int answer = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de que desea salir de DOPOSoccer?",
                "Confirmar Salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        if (answer == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }

    public ConfigPanel getConfigPanel() {
        return configPanel;
    }

    public static void main(String[] args) {
        try {
            // esto evita que se abran 2 procesos distintos si se le oprime run dos veces
            singleInstanceLock = new java.net.ServerSocket(49155);
        } catch (java.io.IOException e) {
            JOptionPane.showMessageDialog(null,
                    "DOPOSoccer ya se está ejecutando en otra ventana.",
                    "Instancia única activa",
                    JOptionPane.WARNING_MESSAGE);
            System.exit(0);
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                DOPOSoccerGUI gui = new DOPOSoccerGUI();
                gui.setVisible(true);
            }
        });
    }
}