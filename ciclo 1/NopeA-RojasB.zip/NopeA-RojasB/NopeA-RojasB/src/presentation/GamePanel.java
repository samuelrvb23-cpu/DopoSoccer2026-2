package presentation;

import domain.Ball;
import domain.Character;
import domain.DOPOSoccerFacade;
import domain.Player;
import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import java.util.Set;
import javax.swing.*;
import javax.swing.border.EmptyBorder;


/**
 * Pantalla del Partido 
 * Permite jugar Jugador vs Jugador en el mismo teclado y visualizar todos los estados.
 */
public class GamePanel extends JPanel {

    private final DOPOSoccerGUI gui;
    private final java.util.List<domain.Ball> fakeBalls = new java.util.ArrayList<>();
    private int fakeBallsTimer = 0;
    private String activePowerCountry = null; // Guarda qué país disparó el tiro de poder activo
    private boolean powerShooterIsP1 = false;

    // Componentes del HUD Superior
    private JLabel lblP1Name;
    private JLabel lblP2Name;
    private JLabel lblScore;
    private JLabel lblTimerOrGoal;
    private JProgressBar barP1Life;
    private JProgressBar barP1Power;
    private JProgressBar barP2Life;
    private JProgressBar barP2Power;

    // Botones de control del partido
    private JButton btnPause;
    private JButton btnEndMatch;

    // Lienzo gráfico de la cancha
    private CourtCanvas courtCanvas;

    // Timers para el bucle 
    private Timer gameLoopTimer;
    private Timer secondTimer;
    private boolean isPaused = false;

    // Colección HashSet para lectura fluida de múltiples teclas simultáneas
    private final Set<Integer> pressedKeys = new HashSet<>();

    // Estado visual para la maqueta interactiva Jugador vs Jugador
    private String p1Country = "Corea del Sur";
    private String p2Country = "Camerún";
    private boolean isByTime = true;
    private int remainingSeconds = 120;
    private int goalsTarget = 5;
    private int goalsP1 = 0;
    private int goalsP2 = 0;
    private DOPOSoccerFacade facade = new DOPOSoccerFacade();

    // Coordenadas y estados visuales en la cancha 
    private double p1X = 150, p1Y = 0, p1Vy = 0;
    private double p2X = 750, p2Y = 0, p2Vy = 0;
    private double ballX = 450, ballY = 150, ballVx = 0, ballVy = 0;
    private boolean p1HasAura = false, p2HasAura = false;
    private int p1StunTicks = 0, p2StunTicks = 0;

    public GamePanel(DOPOSoccerGUI gui) {
        this.gui = gui;
        setFocusable(true);
        prepareView();
        prepareController();
    }

    private void prepareView() {
        setLayout(new BorderLayout());

        // 1. HUD Superior (Marcador, Tiempo, Barras de Vida y Poder)
        JPanel hudPanel = new JPanel(new BorderLayout(15, 5));
        hudPanel.setBackground(new Color(25, 30, 45));
        hudPanel.setBorder(new EmptyBorder(10, 20, 10, 20));

        // Panel Jugador 1 (Izquierda)
        JPanel p1Hud = new JPanel(new GridLayout(3, 1, 2, 4));
        p1Hud.setOpaque(false);
        lblP1Name = new JLabel("J1: Corea del Sur");
        lblP1Name.setForeground(Color.WHITE);
        lblP1Name.setFont(new Font("Arial", Font.BOLD, 14));

        barP1Life = createBar(new Color(40, 200, 80), "Vida: 100%");
        barP1Power = createBar(new Color(0, 180, 255), "Poder: 0%");
        p1Hud.add(lblP1Name);
        p1Hud.add(barP1Life);
        p1Hud.add(barP1Power);

        // Panel Central (Marcador, Tiempo y Botones Pausar/Terminar)
        JPanel centerHud = new JPanel(new GridLayout(3, 1, 2, 2));
        centerHud.setOpaque(false);

        lblScore = new JLabel("0 - 0", SwingConstants.CENTER);
        lblScore.setFont(new Font("Arial", Font.BOLD, 32));
        lblScore.setForeground(new Color(255, 215, 0));

        lblTimerOrGoal = new JLabel("Tiempo: 02:00", SwingConstants.CENTER);
        lblTimerOrGoal.setFont(new Font("Arial", Font.BOLD, 15));
        lblTimerOrGoal.setForeground(Color.WHITE);

        JPanel controlButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        controlButtons.setOpaque(false);
        btnPause = new JButton("Pausar");
        btnEndMatch = new JButton("Terminar");
        btnPause.setFocusable(false);
        btnEndMatch.setFocusable(false);
        controlButtons.add(btnPause);
        controlButtons.add(btnEndMatch);

        centerHud.add(lblScore);
        centerHud.add(lblTimerOrGoal);
        centerHud.add(controlButtons);

        // Panel Jugador 2 (Derecha)
        JPanel p2Hud = new JPanel(new GridLayout(3, 1, 2, 4));
        p2Hud.setOpaque(false);
        lblP2Name = new JLabel("J2: Camerún", SwingConstants.RIGHT);
        lblP2Name.setForeground(Color.WHITE);
        lblP2Name.setFont(new Font("Arial", Font.BOLD, 14));

        barP2Life = createBar(new Color(40, 200, 80), "Vida: 100%");
        barP2Power = createBar(new Color(0, 180, 255), "Poder: 0%");
        p2Hud.add(lblP2Name);
        p2Hud.add(barP2Life);
        p2Hud.add(barP2Power);

        hudPanel.add(p1Hud, BorderLayout.WEST);
        hudPanel.add(centerHud, BorderLayout.CENTER);
        hudPanel.add(p2Hud, BorderLayout.EAST);

        add(hudPanel, BorderLayout.NORTH);

        // 2. Lienzo central de la cancha
        courtCanvas = new CourtCanvas();
        add(courtCanvas, BorderLayout.CENTER);
    }

    private JProgressBar createBar(Color color, String text) {
        JProgressBar bar = new JProgressBar(0, 100);
        bar.setValue(text.startsWith("Vida") ? 100 : 0);
        bar.setStringPainted(true);
        bar.setString(text);
        bar.setForeground(color);
        bar.setPreferredSize(new Dimension(240, 18));
        return bar;
    }

    private void prepareController() {
        // Controlador de botones de Pausa y Terminar
        btnPause.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                togglePauseAction();
            }
        });

        btnEndMatch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                finishMatchAction("Partido terminado manualmente por los jugadores.");
            }
        });

        // Uso de KeyAdapter para capturar ambos jugadores en el mismo teclado
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pressedKeys.add(e.getKeyCode());
                handleSinglePressActions(e.getKeyCode());
            }

            @Override
            public void keyReleased(KeyEvent e) {
                pressedKeys.remove(e.getKeyCode());
            }
        });

        gameLoopTimer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isPaused) {
                    updateVisualSimulation();
                    
                    
                     
                    
                    courtCanvas.repaint();
                }
            }
        }); 
        // Temporizador de 1 segundo para tiempo reglamentario y carga de barra de poder (10s = +10%/s)
        secondTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isPaused) {
                    onSecondElapsed();
                }
            }
        });
    }

    /**
     * Inicializa el estado del partido al entrar desde ConfigPanel.
     */
    public void setupMatch(String mode, String p1, String p2, boolean byTime, int targetValue) {
        this.p1Country = p1;
        this.p2Country = p2;
        this.isByTime = byTime;
        this.goalsP1 = 0;
        this.goalsP2 = 0;
        this.isPaused = false;
        this.p1HasAura = false;
        this.p2HasAura = false;
        this.pressedKeys.clear();

        lblP1Name.setText("J1: " + p1Country);
        lblP2Name.setText("J2: " + p2Country);
        lblScore.setText("0 - 0");

        barP1Life.setValue(100);
        barP1Life.setString("Vida: 100%");
        barP2Life.setValue(100);
        barP2Life.setString("Vida: 100%");
        barP1Power.setValue(0);
        barP1Power.setString("Poder: 0%");
        barP2Power.setValue(0);
        barP2Power.setString("Poder: 0%");

        if (isByTime) {
            remainingSeconds = targetValue * 60;
            updateTimerLabel();
        } else {
            goalsTarget = targetValue;
            lblTimerOrGoal.setText("Meta: Primero en anotar " + goalsTarget + " goles");
        }
        this.activePowerCountry = null;
        this.fakeBalls.clear();
        try {
            facade.configureMatch(p1Country, p2Country);
        } catch (domain.DOPOSoccerException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
        resetPositionsAfterGoal();
        gameLoopTimer.start();
        secondTimer.start();
    }

    public void stopMatchLoop() {
        gameLoopTimer.stop();
        secondTimer.stop();
    }

    private void togglePauseAction() {
        isPaused = !isPaused;
        btnPause.setText(isPaused ? "Reanudar" : "Pausar");
        courtCanvas.repaint();
        requestFocusInWindow();
    }

    /**
     * Acciones instantáneas al presionar tecla: Activar Poder y Patear.
     */
    private void handleSinglePressActions(int keyCode) {
        if (isPaused) return;

        // Jugador 1 activa poder con tecla E (solo si barra == 100% y no tiene aura activa)
        if (keyCode == KeyEvent.VK_E && barP1Power.getValue() >= 100 && !p1HasAura && p1StunTicks == 0) {
            p1HasAura = true;
            barP1Power.setValue(0);
            barP1Power.setString("Poder: 0% (Aura Activa)");
        }

        // Jugador 2 activa poder con tecla ENTER
        if (keyCode == KeyEvent.VK_ENTER && barP2Power.getValue() >= 100 && !p2HasAura && p2StunTicks == 0) {
            p2HasAura = true;
            barP2Power.setValue(0);
            barP2Power.setString("Poder: 0% (Aura Activa)");
        }

        // Patada Jugador 1 (Tecla S)
        if (keyCode == KeyEvent.VK_S && p1StunTicks == 0) {
            executeKick(true);
        }

        // Patada Jugador 2 (Flecha Abajo)
        if (keyCode == KeyEvent.VK_DOWN && p2StunTicks == 0) {
            executeKick(false);
        }
    }

    private void executeKick(boolean isP1) {
        Player activePlayer = isP1 ? facade.getPlayer1() : facade.getPlayer2();
        if (activePlayer != null) {
            activePlayer.setPosX(isP1 ? p1X : p2X);
            activePlayer.setPosY(isP1 ? p1Y : p2Y); 
            activePlayer.kick( null,null ); // Activa la animación del pie amarillo
        }

        // Si el balón está al alcance del pie, aplica la misma colisión polimórfica (con o sin aura)
        double px = (isP1 ? p1X : p2X) + 25;
        double py = (isP1 ? p1Y : p2Y) - 30;
        if (Math.hypot(px - ballX, py - ballY) <= 75) {
            checkPlayerBallCollision(isP1);
        }

        // Daño de patada normal al rival si está cerca
        if (Math.abs(p1X - p2X) < 65 && Math.abs(p1Y - p2Y) < 50) {
            if (isP1) applyDamageToPlayer(false, 10);
            else applyDamageToPlayer(true, 10);
        }
    }

    private void applyDamageToPlayer(boolean hitPlayer1, int damage) {
        JProgressBar lifeBar = hitPlayer1 ? barP1Life : barP2Life;
        int newLife = Math.max(0, lifeBar.getValue() - damage);
        lifeBar.setValue(newLife);
        lifeBar.setString("Vida: " + newLife + "%");

        // Regla de Aturdimiento del PDF: Si llega a 0, queda aturdido 3s y luego reinicia al máximo
        if (newLife == 0) {
            if (hitPlayer1) p1StunTicks = 180; // 3 segundos a 60 FPS
            else p2StunTicks = 180;
        }
    }

    private void onSecondElapsed() {
        // Regla 1 de Poderes: La barra de poder se llena en 10 segundos (+10% por segundo)
        if (barP1Power.getValue() < 100) {
            int v1 = Math.min(100, barP1Power.getValue() + 10);
            barP1Power.setValue(v1);
            barP1Power.setString("Poder: " + v1 + "%");
        }
        if (barP2Power.getValue() < 100) {
            int v2 = Math.min(100, barP2Power.getValue() + 10);
            barP2Power.setValue(v2);
            barP2Power.setString("Poder: " + v2 + "%");
        }

        if (isByTime) {
            if (remainingSeconds > 0) {
                remainingSeconds--;
                updateTimerLabel();
            } else {
                if (goalsP1 != goalsP2) {
                    finishMatchAction("¡Tiempo reglamentario finalizado!");
                } else {
                    lblTimerOrGoal.setText("¡MUERTE SÚBITA!, Gol gana");
                }
            }
        }
    }

    private void updateTimerLabel() {
        int min = remainingSeconds / 60;
        int sec = remainingSeconds % 60;
        lblTimerOrGoal.setText(String.format("Tiempo: %02d:%02d", min, sec));
    }

    /**
     * Actualiza posiciones de jugadores y balón en el modo básico Jugador vs Jugador.
     */
    private void updateVisualSimulation() {
        int w = Math.max(800, courtCanvas.getWidth());
        int groundY = Math.max(350, courtCanvas.getHeight() - 60);

        // Control de aturdimiento 3 segundo
        if (p1StunTicks > 0) {
            p1StunTicks--;
            if (p1StunTicks == 0) {
                barP1Life.setValue(100);
                barP1Life.setString("Vida: 100%");
            }
        }
        if (p2StunTicks > 0) {
            p2StunTicks--;
            if (p2StunTicks == 0) {
                barP2Life.setValue(100);
                barP2Life.setString("Vida: 100%");
            }
        }

        // Movimientos Jugador 1 (A, D, W)
        if (p1StunTicks == 0) {
            if (pressedKeys.contains(KeyEvent.VK_A)) p1X = Math.max(60, p1X - 5);
            if (pressedKeys.contains(KeyEvent.VK_D)) p1X = Math.min(w - 110, p1X + 5);
            if (pressedKeys.contains(KeyEvent.VK_W) && p1Y >= groundY) p1Vy = -13;
        }

        // Movimientos Jugador 2 (Flechas Izquierda, Derecha, Arriba)
        if (p2StunTicks == 0) {
            if (pressedKeys.contains(KeyEvent.VK_LEFT)) p2X = Math.max(60, p2X - 5);
            if (pressedKeys.contains(KeyEvent.VK_RIGHT)) p2X = Math.min(w - 110, p2X + 5);
            if (pressedKeys.contains(KeyEvent.VK_UP) && p2Y >= groundY) p2Vy = -13;
        }

        // Gravedad Jugadores
        p1Y += p1Vy;
        if (p1Y < groundY) p1Vy += 0.7;
        else { p1Y = groundY; p1Vy = 0; }

        p2Y += p2Vy;
        if (p2Y < groundY) p2Vy += 0.7;
        else { p2Y = groundY; p2Vy = 0; }
        double minDistanceX = 50.0; // Ancho de cada personaje
        double dx = p2X - p1X;
        double dy = Math.abs(p1Y - p2Y);

        if (Math.abs(dx) < minDistanceX && dy < 55.0) {
            double overlap = (minDistanceX - Math.abs(dx)) / 2.0;
            if (dx >= 0) {
                // Jugador 1 está a la izquierda y Jugador 2 a la derecha: los separa en partes iguales
                p1X = Math.max(60, p1X - overlap);
                p2X = Math.min(w - 110, p2X + overlap);
            } else {
                // Si se cruzaron por el aire saltando los separa hacia el lado en que cayeron
                p1X = Math.min(w - 110, p1X + overlap);
                p2X = Math.max(60, p2X - overlap);
            }
        }
        // Sincronizar posiciones actuales con el Dominio, para que la patada sepa dónde está
        if (facade.getPlayer1() != null) {
            facade.getPlayer1().setPosX(p1X);
            facade.getPlayer1().setPosY(p1Y);
            facade.getPlayer1().update(); // Actualiza el temporizador para que el pie amarillo se devuelva
        }
        if (facade.getPlayer2() != null) {
            facade.getPlayer2().setPosX(p2X);
            facade.getPlayer2().setPosY(p2Y);
            facade.getPlayer2().update();
        }

        // Física básica del balón (Gravedad y rebotes)
        ballX += ballVx;
        ballY += ballVy;
        ballVy += 0.45; // Gravedad normal

        if (facade.getBall() != null && facade.getBall().hasActivePowerShot()) {
            facade.getBall().setPosX(ballX);
            facade.getBall().setPosY(ballY);
            facade.getBall().setVelX(ballVx);
            facade.getBall().setVelY(ballVy);

            // cada país aplica su trayectoria en el aire (recto o tornado)
            facade.getBall().getActivePowerShot().updatePowerBallPhysics(facade.getBall(), groundY);
            ballY = facade.getBall().getPosY();
            ballVy = facade.getBall().getVelY();

            // Solo desactiva el poder si el balón casi se detiene por completo
            if (Math.abs(ballVx) < 2.0) {
                facade.getBall().clearPowerShot();
                activePowerCountry = null;
            }
        } else {
            // Rebote normal contra el suelo cuando NO es un tiro de poder activo
            if (ballY >= groundY - 12) {
                ballY = groundY - 12;
                ballVy = -ballVy * 0.75;
                ballVx *= 0.98;
            }
        }

        if (ballY < 20) {
            ballY = 20;
            ballVy = -ballVy;
        }

        if (fakeBallsTimer > 0) {
            fakeBallsTimer--;
            for (domain.Ball f : fakeBalls) {
                f.updatePhysics();
                if (f.getPosY() >= groundY - 12) {
                    f.setPosY(groundY - 12);
                    f.setVelY(-f.getVelY() * 0.75);
                }
            }
            if (fakeBallsTimer == 0) fakeBalls.clear();
        }

        // Colisión cabeza/cuerpo de los jugadores con el balón
        checkPlayerBallCollision(true);
        checkPlayerBallCollision(false);

        // Comprobar Goles en los arcos con Altura del arco: groundY - 130
        int goalTop = groundY - 130;
        if (ballX <= 55 && ballY >= goalTop) {
            registerGoal(false); // Gol de Jugador 2
        } else if (ballX >= w - 55 && ballY >= goalTop) {
            registerGoal(true);  // Gol de Jugador 1
        } else if (ballX < 20 || ballX > w - 20) {
            ballVx = -ballVx * 0.8;
        }

        // Sincronizar posición del balón con el dominio
        if (facade.getBall() != null) {
            facade.getBall().setPosX(ballX);
            facade.getBall().setPosY(ballY);
            facade.getBall().setVelX(ballVx);
            facade.getBall().setVelY(ballVy);
        }
    }
    private void checkPlayerBallCollision(boolean isP1) {
        double px = (isP1 ? p1X : p2X) + 25;
        double py = (isP1 ? p1Y : p2Y) - 35;

        Player me = isP1 ? facade.getPlayer1() : facade.getPlayer2();
        Player rival = isP1 ? facade.getPlayer2() : facade.getPlayer1();
        Ball ball = facade.getBall();

        if (me == null || rival == null || ball == null) return;

        double hitRadius = ball.hasActivePowerShot() ? 58.0 : 42.0;

        if (Math.hypot(px - ballX, py - ballY) < hitRadius) {
            boolean hasAura = isP1 ? p1HasAura : p2HasAura;

            // caso # 1: El balón viene con Tiro de Poder del RIVAL y golpea a este jugador
            if (ball.hasActivePowerShot() && powerShooterIsP1 != isP1) {
                Character rivalPower = ball.getActivePowerShot();
                me.setPosX(isP1 ? p1X : p2X);
                int damageDone = (int) Math.round(rivalPower.calculatePowerDamage(rival));

                // Aplica el efecto polimórfico del país en el dominio y limpia el tiro del balón
                rivalPower.onPowerShotHitOpponent(rival, me, ball);

                // Sincroniza empuje (Corea), vida y efectos (Camerún / Nigeria) en pantalla
                if (isP1) p1X = Math.max(60, Math.min(courtCanvas.getWidth() - 110, me.getPosX()));
                else p2X = Math.max(60, Math.min(courtCanvas.getWidth() - 110, me.getPosX()));

                applyDamageToPlayer(isP1, damageDone);

                // Si quedó inconsciente Nigeria o electrocutado Camerún, aplica reacción visual
                if (!me.canAct()) {
                    if (isP1) { p1Vy = -15; p1StunTicks = 180; }
                    else { p2Vy = -15; p2StunTicks = 180; }
                } else if (!me.canJump()) {
                    if (isP1) p1StunTicks = 90;
                    else p2StunTicks = 90;
                }

                activePowerCountry = null;
                ballVx = -ballVx * 0.4;
                ballVy = -7.0;
            }
            // CASO 2: Este jugador tiene Aura activa y toca el balón, por lo que dispara el Tiro de Poder de su país
            else if (hasAura && me.getCharacter() != null) {
                // Eleva el balón 22px del suelo para que los tiros rectos (Corea/Camerún) salgan a media altura
                ballY = Math.min(ballY, (isP1 ? p1Y : p2Y) - 38);
                ball.setPosX(ballX);
                ball.setPosY(ballY);

                me.getCharacter().triggerPowerShot(me, rival, ball);
                ballVx = ball.getVelX();
                ballVy = ball.getVelY();
                activePowerCountry = me.getCharacter().getCountryName();
                powerShooterIsP1 = isP1;

                fakeBalls.clear();
                fakeBalls.addAll(me.getCharacter().createExtraBalls(ballX, ballY, isP1));
                if (!fakeBalls.isEmpty()) fakeBallsTimer = 150;

                if (isP1) p1HasAura = false;
                else p2HasAura = false;
            }
            // CASO 3: Toque normal sin poder
            else if (!ball.hasActivePowerShot()) {
                ballVx = (ballX - px) * 0.35;
                ballVy = -9.5;
            }
        }
    }

    private void registerGoal(boolean scoredByP1) {
        if (scoredByP1) {
            goalsP1++;
            // Regla: Cuando un jugador recibe un gol, su barra aumenta de inmediato 1/4 osea +25%
            int newPow = Math.min(100, barP2Power.getValue() + 25);
            barP2Power.setValue(newPow);
            barP2Power.setString("Poder: " + newPow + "%");
        } else {
            goalsP2++;
            int newPow = Math.min(100, barP1Power.getValue() + 25);
            barP1Power.setValue(newPow);
            barP1Power.setString("Poder: " + newPow + "%");
        }

        lblScore.setText(goalsP1 + " - " + goalsP2);
        resetPositionsAfterGoal();

        // Verificar condición de victoria ya sea por goles o Muerte Súbita
        if (!isByTime && (goalsP1 >= goalsTarget || goalsP2 >= goalsTarget)) {
            finishMatchAction("¡Se alcanzó la meta de goles!");
        } else if (isByTime && remainingSeconds == 0) {
            finishMatchAction("¡Gol de Oro en Muerte Súbita!");
        }
    }

    private void resetPositionsAfterGoal() {
        int w = Math.max(850, getWidth());
        int groundY = Math.max(350, getHeight() - 150);
        // Regla del PDF: Después de cada gol, los personajes y el balón caen desde el centro
        p1X = w * 0.22;
        p1Y = groundY - 80;
        p2X = w * 0.72;
        p2Y = groundY - 80;
        ballX = w * 0.50;
        ballY = 120;
        ballVx = 0;
        ballVy = 0;
    }

    private void finishMatchAction(String reason) {
        stopMatchLoop();
        boolean p1Won = goalsP1 >= goalsP2;
        String winner = (goalsP1 == goalsP2) ? "Empate Técnico"
                : (p1Won ? "Jugador 1 (" + p1Country + ")" : "Jugador 2 (" + p2Country + ")");

        gui.getConfigPanel().addMatchRewardPoints(p1Won);

        JOptionPane.showMessageDialog(this,
                reason + "\n\n" +
                "Marcador Final: " + goalsP1 + " - " + goalsP2 + "\n" +
                "Ganador: " + winner + "\n\n" +
                "Puntos otorgados:\n" +
                "• Ganador: +100 puntos\n" +
                "• Perdedor: +25 puntos",
                "Fin del Partido",
                JOptionPane.INFORMATION_MESSAGE);

        gui.showScreen(DOPOSoccerGUI.CONFIG_VIEW);
    }

    /**
     * Lienzo interno encargado de dibujar la cancha, arcos, jugadores, auras y balón.
     */
    private class CourtCanvas extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int groundY = h - 60;

            // Fondo de estadio y césped
            g2.setColor(new Color(135, 206, 235));
            g2.fillRect(0, 0, w, groundY);
            g2.setColor(new Color(46, 139, 87));
            g2.fillRect(0, groundY, w, 60);

            // Línea central de la cancha
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(3));
            g2.drawLine(w / 2, groundY, w / 2, groundY + 60);

            // Arcos Izquierdo y Derecho
            int goalHeight = 130;
            g2.setColor(Color.WHITE);
            g2.drawRect(10, groundY - goalHeight, 45, goalHeight);
            g2.drawRect(w - 55, groundY - goalHeight, 45, goalHeight);

            // Dibujar Jugador 1 y Jugador 2
            drawCharacter(g2, (int) p1X, (int) p1Y, new Color(30, 144, 255), p1Country, p1HasAura, p1StunTicks > 0, true);
            drawCharacter(g2, (int) p2X, (int) p2Y, new Color(220, 53, 69), p2Country, p2HasAura, p2StunTicks > 0, false);
            // balones falso
            for (domain.Ball f : fakeBalls) {
                g2.setColor(Color.WHITE);
                g2.fillOval((int) f.getPosX() - 14, (int) f.getPosY() - 14, 28, 28);
                g2.setColor(Color.BLACK);
                g2.drawOval((int) f.getPosX() - 14, (int) f.getPosY() - 14, 28, 28);
            }

            // Dibujar efecto visual del poder activo alrededor del balón
            if (facade.getBall() != null && facade.getBall().hasActivePowerShot()) {
                int rgb = facade.getBall().getActivePowerShot().getPowerColorRGB();
                Color c = new Color(rgb);
                g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 185));
                g2.fillOval((int) ballX - 24, (int) ballY - 24, 48, 48);
            }

            // Dibujar Balón
            g2.setColor(Color.WHITE);
            g2.fillOval((int) ballX - 14, (int) ballY - 14, 28, 28);
            g2.setColor(Color.BLACK);
            g2.drawOval((int) ballX - 14, (int) ballY - 14, 28, 28);

            // Mensaje superpuesto si está en Pausa
            if (isPaused) {
                g2.setColor(new Color(0, 0, 0, 150));
                g2.fillRect(0, 0, w, h);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 40));
                g2.drawString("JUEGO EN PAUSA", w / 2 - 170, h / 2);
            }
        }

        private void drawCharacter(Graphics2D g2, int x, int y, Color color, String country, boolean hasAura, boolean isStunned, boolean isP1) {
            // Aura de poder activo
            if (hasAura) {
                g2.setColor(new Color(255, 215, 0, 140));
                g2.fillOval(x - 12, y - 82, 74, 90);
            }

            // Cabeza grande estilo Head Soccer
            g2.setColor(color);
            g2.fillOval(x, y - 65, 50, 50);
            
            // Cuerpo / Torso
            g2.setColor(Color.DARK_GRAY);
            g2.fillRoundRect(x + 10, y - 15, 30, 15, 8, 8);

            // --- EFECTO VISUAL DE LA PATADA ---
            // Verificamos si el jugador del dominio está ejecutando la patada
            boolean kicking = isP1 ? facade.getPlayer1().isKicking() : facade.getPlayer2().isKicking();
            if (kicking) {
                g2.setColor(Color.YELLOW); // Color brillante para resaltar el botín al patear
                // Dibuja la pierna extendido hacia adelante dependiendo del jugador
                int footX = isP1 ? x + 38 : x - 12;
                g2.fillRect(footX, y - 18, 24, 12);
            }

            // Etiqueta de país y estado de aturdimiento
            g2.setColor(Color.BLACK);
            g2.setFont(new Font("Arial", Font.BOLD, 12));
            g2.drawString(country, x - 5, y - 72);

            if (isStunned) {
                g2.setColor(Color.YELLOW);
                g2.drawString("¡ATURDIDO!", x - 10, y - 88);
            }
        }
        
}

}