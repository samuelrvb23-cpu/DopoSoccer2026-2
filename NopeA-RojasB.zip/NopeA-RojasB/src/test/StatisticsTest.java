package test;

import domain.Statistics;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

pubxlic class StatisticsTest {

    @Test
    public void testInitialValues() {
        Statistics stats = new Statistics();
        assertEquals(1, stats.getSpeed());
        assertEquals(1, stats.getJump());
        assertEquals(1, stats.getKick());
        assertEquals(1, stats.getSurvival());
        assertEquals(1.0, stats.getKickMultiplier(), 0.0001);
        assertEquals(100.0, stats.getMaxHealth(), 0.0001);
    }

    @Test
    public void testKickAndSurvivalFormulasFromExample() {
        Statistics stats = new Statistics();
        // Subir Kick a 5 -> multiplicador 1.4
        for (int i = 0; i < 4; i++) {
            assertTrue(stats.upgradeKick());
        }
        assertEquals(5, stats.getKick());
        assertEquals(1.4, stats.getKickMultiplier(), 0.0001);

        // Subir Survival a 3 -> vidaMax 120.0
        assertTrue(stats.upgradeSurvival());
        assertTrue(stats.upgradeSurvival());
        assertEquals(3, stats.getSurvival());
        assertEquals(120.0, stats.getMaxHealth(), 0.0001);
    }

    @Test
    public void testMaxLevelLimit() {
        Statistics stats = new Statistics();
        for (int i = 1; i < 10; i++) {
            assertTrue(stats.upgradeSpeed());
            assertTrue(stats.upgradeJump());
            assertTrue(stats.upgradeKick());
            assertTrue(stats.upgradeSurvival());
        }
        assertEquals(10, stats.getSpeed());
        assertEquals(190.0, stats.getMaxHealth(), 0.0001);
        assertEquals(1.9, stats.getKickMultiplier(), 0.0001);

        // No debe pasar de 10
        assertFalse(stats.upgradeSpeed());
        assertFalse(stats.upgradeJump());
        assertFalse(stats.upgradeKick());
        assertFalse(stats.upgradeSurvival());
    }

    @Test
    public void testUpgradeCostDoubling() {
        Statistics stats = new Statistics();
        assertEquals(500, stats.getUpgradeCost(1));
        assertEquals(1000, stats.getUpgradeCost(2));
        assertEquals(2000, stats.getUpgradeCost(3));
        assertEquals(4000, stats.getUpgradeCost(4));
    }
}