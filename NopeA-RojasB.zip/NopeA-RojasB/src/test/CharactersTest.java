package test;

import domain.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

    public class CharactersTest {

        @Test
        public void testCameroonPowerShotExampleFromPDF() {
            // Ejemplo del Anexo 2: Camerún con Kick 5 (mult 1.4) vs rival con Survival 3 (vida 120)
            Statistics s1 = new Statistics();
            for (int i = 0; i < 4; i++) s1.upgradeKick();
            Statistics s2 = new Statistics();
            s2.upgradeSurvival();
            s2.upgradeSurvival();

        Player p1 = new Player(100, 300, true, s1, new CameroonCharacter());
        Player p2 = new Player(300, 300, false, s2, new KoreaCharacter());
        Ball ball = new Ball(120, 280);

        p1.chargePowerBar(100.0);
        p1.activatePower();
        p1.getCharacter().triggerPowerShot(p1, p2, ball);

        assertFalse(p1.hasActiveAura());
        assertTrue(ball.hasActivePowerShot());

        ball.getActivePowerShot().onPowerShotHitOpponent(p1, p2, ball);
        assertEquals(36.0, p2.getCurrentLife(), 0.0001);
        assertEquals(Player.EFFECT_ELECTROCUTED, p2.getActiveEffect());
        assertFalse(ball.hasActivePowerShot());
    }

    @Test
    public void testKoreaPushEffect() {
        Player p1 = new Player(100, 300, true, new Statistics(), new KoreaCharacter());
        Player p2 = new Player(300, 300, false, new Statistics(), new CameroonCharacter());
        Ball ball = new Ball(120, 280);

        p1.getCharacter().executePowerShot(p1, p2, ball);
        assertEquals(60.0, p2.getCurrentLife(), 0.0001);
        assertEquals(400.0, p2.getPosX(), 0.0001);
        assertEquals(Player.EFFECT_PUSHED, p2.getActiveEffect());
    }

    @Test
    public void testNigeriaUnconsciousEffect() {
        Player p1 = new Player(100, 300, true, new Statistics(), new NigeriaCharacter());
        Player p2 = new Player(300, 300, false, new Statistics(), new CameroonCharacter());
        Ball ball = new Ball(120, 280);

        p1.getCharacter().executePowerShot(p1, p2, ball);
        assertEquals(60.0, p2.getCurrentLife(), 0.0001);
        assertEquals(Player.EFFECT_UNCONSCIOUS, p2.getActiveEffect());
        assertFalse(p2.canAct());
    }

    @Test
    public void testUSAIllusionCreatesSevenFakeBalls() {
        USACharacter usa = new USACharacter();
        List<Ball> extras = usa.createExtraBalls(200, 250, true);
        assertEquals(7, extras.size());
        for (Ball fake : extras) {
            assertTrue(fake.isFake());
        }
    }
}