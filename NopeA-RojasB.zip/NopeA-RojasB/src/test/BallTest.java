package test;

import domain.Ball;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BallTest {

    @Test
    public void testNormalKickGravityAndReset() {
        Ball ball = new Ball(400, 200);
        ball.applyNormalKick(true);
        assertTrue(ball.getVelX() > 0);
        assertTrue(ball.getVelY() < 0);

        double prevY = ball.getPosY();
        ball.updatePhysics();
        assertNotEquals(prevY, ball.getPosY());

        ball.resetPosition(425, 200);
        assertEquals(425.0, ball.getPosX(), 0.0001);
        assertEquals(200.0, ball.getPosY(), 0.0001);
        assertEquals(0.0, ball.getVelX(), 0.0001);
        assertEquals(0.0, ball.getVelY(), 0.0001);
    }
}