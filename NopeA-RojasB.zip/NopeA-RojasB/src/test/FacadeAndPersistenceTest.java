package test;

import domain.*;
import org.junit.jupiter.api.Test;
import java.io.*;
import static org.junit.jupiter.api.Assertions.*;

public class FacadeAndPersistenceTest {

    @Test
    public void testConfigureMatchAndInvalidCountryException() throws DOPOSoccerException {
        DOPOSoccerFacade facade = new DOPOSoccerFacade();
        facade.configureMatch("Nigeria", "Estados Unidos");

        assertEquals("Nigeria", facade.getPlayer1().getCharacter().getCountryName());
        assertEquals("Estados Unidos", facade.getPlayer2().getCharacter().getCountryName());

        assertThrows(DOPOSoccerException.class, () -> {
            facade.configureMatch("Brasil", "Camerún");
        });
    }

    @Test
    public void testAIModeReturnsValidAction() throws DOPOSoccerException {
        DOPOSoccerFacade facade = new DOPOSoccerFacade();
        facade.configureMatch("Corea del Sur", "Camerún");
        facade.setMatchMode(true, "Ofensiva");

        assertTrue(facade.isVsMachine());
        String action = facade.decideCpuAction();
        assertNotNull(action);
    }

    @Test
    public void testSaveAndLoadMatchSerialization() throws Exception {
        DOPOSoccerFacade facade = new DOPOSoccerFacade();
        facade.configureMatch("Corea del Sur", "Nigeria");
        facade.getPlayer1().scoreGoal();
        facade.getPlayer1().scoreGoal();
        facade.getPlayer2().scoreGoal();

        MatchSaveData original = new MatchSaveData(
                facade, true, 75, 5, "Jugador vs Jugador", "Experta", "Corea del Sur", "Nigeria"
        );

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeObject(original);
        }

        MatchSaveData restored;
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()))) {
            restored = (MatchSaveData) ois.readObject();
        }

        assertEquals(2, restored.facade.getPlayer1().getGoals());
        assertEquals(1, restored.facade.getPlayer2().getGoals());
        assertEquals(75, restored.remainingSeconds);
        assertEquals("Corea del Sur", restored.p1Country);
        assertEquals("Nigeria", restored.p2Country);
    }
}
