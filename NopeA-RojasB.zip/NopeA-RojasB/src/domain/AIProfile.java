package domain;

import java.io.Serializable;
import java.util.Random;

/**
 * Interfaz que define el contrato de decisión para los perfiles de Inteligencia Artificial (CPU).
 */
public interface AIProfile extends Serializable {
    String ACTION_IDLE = "IDLE";
    String ACTION_MOVE_LEFT = "LEFT";
    String ACTION_MOVE_RIGHT = "RIGHT";
    String ACTION_JUMP = "JUMP";
    String ACTION_KICK = "KICK";
    String ACTION_POWER = "POWER";

    /**
     * Decide la siguiente acción del jugador controlado por la CPU según el estado del partido.
     */
    String decideAction(Player aiPlayer, Player opponent, Ball ball);
}

/**
 * Perfil Torpe: actúa de forma mayoritariamente pasiva o aleatoria.
 */
class AITorpe implements AIProfile {
    private static final long serialVersionUID = 1L;
    private final Random random = new Random();

    @Override
    public String decideAction(Player aiPlayer, Player opponent, Ball ball) {
        if (random.nextInt(100) < 65) {
            return ACTION_IDLE;
        }
        String[] actions = {ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_JUMP, ACTION_KICK, ACTION_POWER};
        return actions[random.nextInt(actions.length)];
    }
}

/**
 * Perfil Ofensiva: prioriza ir hacia el balón, activar poder y patear para atacar.
 */
class AIOfensiva implements AIProfile {
    private static final long serialVersionUID = 1L;

    @Override
    public String decideAction(Player aiPlayer, Player opponent, Ball ball) {
        if (aiPlayer.getPowerBar() >= 100.0 && !aiPlayer.hasActiveAura()) {
            return ACTION_POWER;
        }
        double dx = ball.getPosX() - aiPlayer.getPosX();
        double dy = ball.getPosY() - aiPlayer.getPosY();
        if (Math.hypot(dx, dy) <= 65.0) {
            return ACTION_KICK;
        }
        if (dy < -45.0 && Math.abs(dx) < 80.0) {
            return ACTION_JUMP;
        }
        return dx > 12.0 ? ACTION_MOVE_RIGHT : (dx < -12.0 ? ACTION_MOVE_LEFT : ACTION_IDLE);
    }
}

/**
 * Perfil Defensiva: prioriza resguardar su zona defensiva y despejar cuando el balón se acerca.
 */
class AIDefensiva implements AIProfile {
    private static final long serialVersionUID = 1L;

    @Override
    public String decideAction(Player aiPlayer, Player opponent, Ball ball) {
        double defendX = (aiPlayer.getPosX() >= 400.0) ? 720.0 : 120.0;
        double distBall = Math.abs(ball.getPosX() - aiPlayer.getPosX());

        if (distBall < 90.0 && Math.abs(ball.getPosY() - aiPlayer.getPosY()) < 65.0) {
            return ACTION_KICK;
        }
        if (ball.getPosY() < aiPlayer.getPosY() - 50.0 && distBall < 90.0) {
            return ACTION_JUMP;
        }
        if (aiPlayer.getPosX() < defendX - 25.0) {
            return ACTION_MOVE_RIGHT;
        }
        if (aiPlayer.getPosX() > defendX + 25.0) {
            return ACTION_MOVE_LEFT;
        }
        return ACTION_IDLE;
    }
}

/**
 * Perfil Experta: combina ataque, salto aéreo, patada y activación estratégica del tiro de poder.
 */
class AIExperta implements AIProfile {
    private static final long serialVersionUID = 1L;

    @Override
    public String decideAction(Player aiPlayer, Player opponent, Ball ball) {
        double dx = ball.getPosX() - aiPlayer.getPosX();
        double dy = ball.getPosY() - aiPlayer.getPosY();
        double dist = Math.hypot(dx, dy);

        if (aiPlayer.getPowerBar() >= 100.0 && !aiPlayer.hasActiveAura() && dist < 240.0) {
            return ACTION_POWER;
        }
        if (dist <= 65.0) {
            return ACTION_KICK;
        }
        if (dy < -40.0 && Math.abs(dx) < 95.0) {
            return ACTION_JUMP;
        }
        if (Math.abs(dx) > 10.0) {
            return dx > 0 ? ACTION_MOVE_RIGHT : ACTION_MOVE_LEFT;
        }
        return ACTION_IDLE;
    }
}