package domain;

/**
 * Personaje Estados Unidos :
 * Tiro: una ilusión Se divide en 8 balones idénticos,de los cuales 7 son falsos
 * 
 */
public class USACharacter extends Character {
    private static final long serialVersionUID = 1L;

    public USACharacter() {
        super("Estados Unidos", "Ilusión", 30.0, 2.5);
    }

    @Override
    protected void launchPowerBall(Player user, Ball ball) {
        ball.setVelX(user.isFacingRight() ? 18.0 : -18.0);
        ball.setVelY(-4.0);
    }

    @Override
    protected void applySpecificEffect(Player user, Player opponent) {
        opponent.applyConfusionEffect(effectDurationSeconds);
    }
    @Override
    public int getPowerColorRGB() { 
        return 0xB400FF;// Violeta Ilusión
     } 
    @Override
    public java.util.List<Ball> createExtraBalls(double startX, double startY, boolean facingRight) {
        java.util.List<Ball> extras = new java.util.ArrayList<>();
        double dir = facingRight ? 1.0 : -1.0;
        double[] vyFake = {-12, -9, -5, -2, 2, 5, 8};
        for (int i = 0; i < 7; i++) {
            Ball fake = new Ball(startX, startY, true);
            fake.setVelX((13.0 + i) * dir);
            fake.setVelY(vyFake[i]);
            extras.add(fake);
        }
        return extras;
    }
}