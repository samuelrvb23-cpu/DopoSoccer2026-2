package domain;

/**
 * Personaje Corea del Sur:
 * Tiro: Aura Azul, recto y horizontal a alta velocidad.
 * Efecto: Empuje hacia su propio  | Daño base: 40.
 */
public class KoreaCharacter extends Character {
    private static final long serialVersionUID = 1L;

    public KoreaCharacter() {
        super("Corea del Sur", "Aura Azul", 40.0, 1.5);
    }

    @Override
    protected void launchPowerBall(Player user, Ball ball) {
        ball.setVelX(user.isFacingRight() ? 25.0 : -25.0);
        ball.setVelY(0.0); // Sale recto y horizontal
    }

    @Override
    protected void applySpecificEffect(Player user, Player opponent) {
        opponent.pushBack(user.isFacingRight() ? 100.0 : -100.0);
    }
    @Override
    public void updatePowerBallPhysics(Ball ball, double groundY) {
         ball.setVelY(0.0); 
        }
    @Override
    public int getPowerColorRGB() { 
        return 0x0096FF; 
    }
}