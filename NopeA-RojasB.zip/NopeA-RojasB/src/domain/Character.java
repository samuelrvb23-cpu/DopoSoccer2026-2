package domain;

import java.io.Serializable;

public abstract class Character implements Serializable {
    private static final long serialVersionUID = 1L;
    
    protected String countryName;
    protected String powerName;
    protected double basePowerDamage;// DañoTiro * 5 
    protected double effectDurationSeconds;

    public Character(String countryName, String powerName, double basePowerDamage) {
        this(countryName, powerName, basePowerDamage, 3.0);
    }
    public Character(String countryName, String powerName, double basePowerDamage,double effectDurationSeconds) {
        this.countryName = countryName;
        this.powerName = powerName;
        this.basePowerDamage = basePowerDamage;
        this.effectDurationSeconds = effectDurationSeconds;
    }
    
    public final void triggerPowerShot(Player user, Player opponent, Ball ball) {
        if (user != null && ball != null) {
            user.consumePowerAura();
            ball.activatePowerShot(this, user);
            launchPowerBall(user, ball);
        }
    }

    /**
     * Se invoca cuando el balón con tiro de poder golpea al rival 
     */
    public final void onPowerShotHitOpponent(Player shooter, Player opponent, Ball ball) {
        if (shooter != null && opponent != null) {
            double damage = calculatePowerDamage(shooter);
            opponent.receiveDamage(damage);
            applySpecificEffect(shooter, opponent);
            if (ball != null) {
                ball.clearPowerShot();
            }
        }
    }
    public final void executePowerShot(Player user, Player opponent, Ball ball) {
        if (user != null && ball != null) {
            launchPowerBall(user, ball);
        }
        if (user != null && opponent != null) {
            double damage = calculatePowerDamage(user);
            opponent.receiveDamage(damage);
            applySpecificEffect(user, opponent);
        }
    }
    
    public double calculatePowerDamage(Player user) {
        double multiplier = (user != null && user.getStats() != null)
                ? user.getStats().getKickMultiplier() : 1.0;
        return basePowerDamage * multiplier;
    }

    protected abstract void launchPowerBall(Player user, Ball ball);

    protected abstract void applySpecificEffect(Player user, Player opponent);
    public abstract int getPowerColorRGB();
    public void updatePowerBallPhysics(Ball ball, double groundY) {
        
    }
    public String getCountryName() {
         return countryName;
    }
    public String getPowerName() { 
        return powerName; 
    }
    public double getBasePowerDamage() {
         return basePowerDamage; 
        }
    public double geteffectDurationSeconds() { 
        return effectDurationSeconds; 
    }
    public java.util.List<Ball> createExtraBalls(double startX, double startY, boolean facingRight) {
        return new java.util.ArrayList<>(); // Por defecto 0 balones
    }
}