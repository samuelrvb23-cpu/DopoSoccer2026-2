package domain;

import java.io.Serializable;

/**
 * Contenedor serializable con el estado del dominio y las reglas del partido en curso.
 */
public class MatchSaveData implements Serializable {
    private static final long serialVersionUID = 1L;

    public final DOPOSoccerFacade facade;
    public final boolean isByTime;
    public final int remainingSeconds;
    public final int goalsTarget;
    public final String mode;
    public final String cpuProfile;
    public final String p1Country;
    public final String p2Country;

    public MatchSaveData(DOPOSoccerFacade facade, boolean isByTime, int remainingSeconds,
                        int goalsTarget, String mode, String cpuProfile,
                        String p1Country, String p2Country) {
        this.facade = facade;
        this.isByTime = isByTime;
        this.remainingSeconds = remainingSeconds;
        this.goalsTarget = goalsTarget;
        this.mode = mode;
        this.cpuProfile = cpuProfile;
        this.p1Country = p1Country;
        this.p2Country = p2Country;
    }
}