package domain;

import java.io.Serializable;

public class Ball implements Serializable {
    private static final long serialVersionUID = 1L;


    public static final double GRAVITY = 0.45;
    public static final double AIR_FRICTION = 0.99;
    public static final double BOUNCE_DAMPING = 0.75;
    public static final double RADIUS = 14.0;

    // Constantes físicas: conducción rasante, cabezazo y disparo de patada
    public static final double DRIBBLE_SPEED_X = 6.5;
    public static final double HEADER_SPEED_X = 7.5;
    public static final double HEADER_SPEED_Y = -6.0;
    public static final double KICK_SPEED_X = 16.0;
    public static final double KICK_SPEED_Y = -5.5;

    // Evita que el cuerpo del pateador frene su propio disparo en el siguiente fotograma
    private Player lastKicker;
    private int kickImmunityFrames;

    private double posX, posY;
    private double velX, velY;

    private boolean isFake; // Para el poder Ilusión de Estados Unidos balones falsos
    private Character activePowerShot; // Referencia al poder que lleva el balón 
    private Player lastShooter;
    
    public Ball(double startX, double startY) {
        this(startX,startY,false);
    }
    public Ball(double startX, double startY, boolean isFake) {
        this.posX = startX;
        this.posY = startY;
        this.velX = 0;
        this.velY = 0;
        this.isFake = isFake;
        this.activePowerShot = null;
        this.lastShooter = null;
        this.lastKicker = null;
        this.kickImmunityFrames = 0;
    }
    public void updatePhysics() {
        posX += velX;
        posY += velY;
        velY += GRAVITY;
        velX *= AIR_FRICTION;
        if (kickImmunityFrames > 0) {
            kickImmunityFrames--;
            if (kickImmunityFrames == 0) {
                lastKicker = null;
            }
        }
    }
    /**
     * Toque o conducción con el cuerpo:
     * En el césped empuja el balón recto sin parábola; en el aire o por arriba hace cabezazo.
     */
    public void applyBodyTouch(double playerCenterX, double playerCenterY, boolean isPlayerJumping, Player toucher) {
        boolean immune = (kickImmunityFrames > 0 && toucher != null && toucher == lastKicker);
        if (!immune) {
            double dx = this.posX - playerCenterX;
            double direction = (dx >= 0) ? 1.0 : -1.0;
            boolean movingFastAway = (dx * this.velX > 0) && (Math.abs(this.velX) > DRIBBLE_SPEED_X);

            if (!movingFastAway) {
                boolean isHeader = isPlayerJumping || (this.posY < playerCenterY - 15.0);
                if (isHeader) {
                    this.velX = direction * HEADER_SPEED_X;
                    this.velY = HEADER_SPEED_Y;
                } else {
                    this.velX = direction * DRIBBLE_SPEED_X;
                    if (this.velY < 0) {
                        this.velY = 0.0;
                    }
                }
                this.posX += direction * 4.0;
            }
        }
    }
    public void applyNormalKick(boolean facingRight) {
        applyNormalKick(facingRight, null);
    }
    public void applyNormalKick(boolean facingRight, Player kicker) {
        double direction = facingRight ? 1.0 : -1.0;
        this.velX = direction * KICK_SPEED_X;
        this.velY = KICK_SPEED_Y;
        this.posX += direction * 8.0;
        this.lastKicker = kicker;
        this.kickImmunityFrames = 6;
    }
    /**
     * Disparo potente al presionar la tecla de patada (fuerza constante según reglas del juego).
     */
    

    public void bounceVertical(double limitY) {
        this.posY = limitY;
        this.velY = -this.velY * BOUNCE_DAMPING;
        if (Math.abs(this.velY) < 0.8) {
            this.velY = 0.0;
        }
    }

    /**
     * Rebota horizontalmente contra los bordes o travesaños.
     */
    public void bounceHorizontal(double limitX) {
        this.posX = limitX;
        this.velX = -this.velX * 0.80;
    }

    /**
     * Reinicia el balón en el centro de la cancha después de un gol 
     */
    public void resetPosition(double centerX, double centerY) {
        this.posX = centerX;
        this.posY = centerY;
        this.velX = 0;
        this.velY = 0;
        this.lastKicker = null;
        this.kickImmunityFrames = 0;
        clearPowerShot();
    }

    public void activatePowerShot(Character power, Player shooter) {
        this.activePowerShot = power;
        this.lastShooter = shooter;
        this.lastKicker = shooter;
        this.kickImmunityFrames = 6;
    }

    public void clearPowerShot() {
        this.activePowerShot = null;
        this.lastShooter = null;
    }

    public boolean hasActivePowerShot() {
        return activePowerShot != null;
    }

    
    public double getPosX() { return posX; }
    public double getPosY() { return posY; }
    public void setPosX(double posX) { this.posX = posX; }
    public void setPosY(double posY) { this.posY = posY; }
    public double getVelX() { return velX; }
    public void setVelX(double velX) { this.velX = velX; }
    public double getVelY() { return velY; }
    public void setVelY(double velY) { this.velY = velY; }
    public boolean isFake() { return isFake; }
    public Character getActivePowerShot() { return activePowerShot; }
    public Player getLastShooter() { return lastShooter; }
}