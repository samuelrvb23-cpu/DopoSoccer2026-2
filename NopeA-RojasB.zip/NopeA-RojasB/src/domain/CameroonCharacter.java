package domain;

/**
 * Personaje Camerún 
 * Tiro: Rayo (Recto, cubierto de electricidad).
 * Efecto: Electrocutado, no puede saltar 
 */
public class CameroonCharacter extends Character {
    private static final long serialVersionUID = 1L;

    public CameroonCharacter() {
        super("Camerún", "Rayo", 60.0, 3.0);
    }

    @Override
    protected void launchPowerBall(Player user, Ball ball) {
        ball.setVelX(user.isFacingRight() ? 22.0 : -22.0);
        ball.setVelY(0.0); // Sale recto
    }

    @Override
    protected void applySpecificEffect(Player user, Player opponent) {
        opponent.applyElectrocutedEffect(effectDurationSeconds);
    }
    @Override
    public void updatePowerBallPhysics(Ball ball, double groundY) { 
    ball.setVelY(0.0); 
    }
    @Override
    public int getPowerColorRGB() { 
    return 0xFFE600; 
    }
}