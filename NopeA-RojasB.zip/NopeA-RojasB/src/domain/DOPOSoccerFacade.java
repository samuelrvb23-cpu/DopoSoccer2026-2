package domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * Fachada del Dominio.
 * Coordina los personajes registrados, los jugadores, el balón y el perfil de IA activo.
 */
public class DOPOSoccerFacade implements Serializable {
    private static final long serialVersionUID = 1L;

    // Colección con clave ordenada alfabéticamente para fácil extensión de países
    private final TreeMap<String, Character> availableCharacters;
    // Colección de balones en cancha (permite soportar los 7 balones falsos de EE.UU.)
    private final List<Ball> activeBalls;

    private Player player1;
    private Player player2;
    private Ball ball;

    // Estado de modalidad Jugador vs Máquina (CPU)
    private boolean vsMachine;
    private AIProfile cpuProfile;

    public DOPOSoccerFacade() {
        this.availableCharacters = new TreeMap<>();
        this.activeBalls = new ArrayList<>();
        registerDefaultCharacters();

        this.player1 = new Player(150, 350, true, new Statistics(), getCharacterByCountry("Corea del Sur"));
        this.player2 = new Player(700, 350, false, new Statistics(), getCharacterByCountry("Camerún"));
        this.ball = new Ball(425, 200);
        this.activeBalls.add(this.ball);
        this.vsMachine = false;
        this.cpuProfile = null;
    }

    /**
     * Registra los 4 países del Anexo 1. Añadir un nuevo país en el futuro solo requiere escribir acá.
     */
    private void registerDefaultCharacters() {
        registerCharacter(new KoreaCharacter());
        registerCharacter(new CameroonCharacter());
        registerCharacter(new NigeriaCharacter());
        registerCharacter(new USACharacter());
    }

    public void registerCharacter(Character character) {
        if (character != null) {
            availableCharacters.put(character.getCountryName(), character);
        }
    }

    public Character getCharacterByCountry(String countryName) {
        Character selected = availableCharacters.get(countryName);
        if (selected == null) {
            selected = new KoreaCharacter();
        }
        return selected;
    }

    /**
     * Configura un nuevo partido asignando el país elegido a cada jugador.
     */
    public void configureMatch(String p1Country, String p2Country) throws DOPOSoccerException {
        if (!availableCharacters.containsKey(p1Country) || !availableCharacters.containsKey(p2Country)) {
            throw new DOPOSoccerException(DOPOSoccerException.INVALID_COUNTRY);
        }
        player1.setCharacter(availableCharacters.get(p1Country));
        player2.setCharacter(availableCharacters.get(p2Country));
        player1.resetForNewMatch();
        player2.resetForNewMatch();
        activeBalls.clear();
        ball.resetPosition(425, 200);
        activeBalls.add(ball);
    }

    /**
     * Configura si el Jugador 2 es controlado por la CPU y asigna el perfil de IA elegido.
     */
    public void setMatchMode(boolean vsMachine, String profileName) {
        this.vsMachine = vsMachine;
        if (!vsMachine) {
            this.cpuProfile = null;
            return;
        }
        if ("Torpe".equalsIgnoreCase(profileName)) {
            this.cpuProfile = new AITorpe();
        } else if ("Ofensiva".equalsIgnoreCase(profileName)) {
            this.cpuProfile = new AIOfensiva();
        } else if ("Defensiva".equalsIgnoreCase(profileName)) {
            this.cpuProfile = new AIDefensiva();
        } else {
            this.cpuProfile = new AIExperta();
        }
    }

    public boolean isVsMachine() {
        return vsMachine;
    }

    /**
     * Solicita al perfil de IA activo la siguiente acción para el Jugador 2.
     */
    public String decideCpuAction() {
        if (!vsMachine || cpuProfile == null || player2 == null || ball == null) {
            return AIProfile.ACTION_IDLE;
        }
        return cpuProfile.decideAction(player2, player1, ball);
    }

    public void kickPlayer1() {
        if (player1 != null && ball != null) {
            player1.kick(ball, player2);
        }
    }

    public void kickPlayer2() {
        if (player2 != null && ball != null) {
            player2.kick(ball, player1);
        }
    }

    public void updateGame() {
        if (player1 != null) {
            player1.update();
        }
        if (player2 != null) {
            player2.update();
        }
        for (Ball b : activeBalls) {
            b.updatePhysics();
        }
    }

    public Player getPlayer1() { return player1; }
    public Player getPlayer2() { return player2; }
    public Ball getBall() { return ball; }
    public List<Ball> getActiveBalls() { return activeBalls; }
    public TreeMap<String, Character> getAvailableCharacters() { return availableCharacters; }
}