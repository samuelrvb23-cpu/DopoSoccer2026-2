package domain;

/**
 * Personaje Nigeria - Anexo 1:
 * Tiro: Tornado (Remolino a ras de suelo que rebota rápidamente).
 * Efecto: Inconsciente, lanzado al aire y no puede moverse, saltar ni patear 3.0 s.
 */
public class NigeriaCharacter extends Character {
    private static final long serialVersionUID = 1L;

    public NigeriaCharacter() {
        super("Nigeria", "Tornado", 40.0, 3.0);
    }

    @Override
    protected void launchPowerBall(Player user, Ball ball) {
        ball.setVelX(user.isFacingRight() ? 16.0 : -16.0);
        ball.setVelY(6.0); // Hacia el suelo para que rebote rápidamente a ras de piso
    }

    @Override
    protected void applySpecificEffect(Player user, Player opponent) {
        opponent.applyUnconsciousEffect(effectDurationSeconds);
    }
    @Override
    public void updatePowerBallPhysics(Ball ball, double groundY) {
    ball.setVelY(ball.getVelY() + 1.1);
    if (ball.getPosY() >= groundY - 14) {
        ball.setPosY(groundY - 14);
        ball.setVelY(-11.0); // Rebote rápido de Tornado
    }
    }
    @Override
    public int getPowerColorRGB() { return 0x32CD32; } // Verde Tornado
}