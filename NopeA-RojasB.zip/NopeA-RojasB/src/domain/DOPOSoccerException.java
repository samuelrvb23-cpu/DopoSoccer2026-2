package domain;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.time.LocalDateTime;

/**
 * Excepción propia del dominio de DOPOSoccer.
 * Incluye el registro en archivo de log para los programadores 
 */
public class DOPOSoccerException extends Exception {
    private static final long serialVersionUID = 1L;

    public static final String INVALID_COUNTRY = "El personaje (país) seleccionado no existe.";
    public static final String MAX_STAT_REACHED = "La estadística ya alcanzó el nivel máximo permitido.";
    public static final String INSUFFICIENT_POINTS = "No tienes suficientes puntos para realizar esta mejora.";
    public static final String INVALID_MATCH_TARGET = "El tiempo o número de goles debe ser mayor que cero.";
    public static final String PERSISTENCE_ERROR = "Error al guardar o abrir el archivo de la partida.";

    public DOPOSoccerException(String message) {
        super(message);
        record(this);
    }

    public DOPOSoccerException(String message, Throwable cause) {
        super(message, cause);
        record(this);
    }

    /**
     * Registra el error en el archivo DOPOSoccer.log usando PrintWriter y FileOutputStream 
     */
    public static void record(Throwable exception) {
        try (PrintWriter pw = new PrintWriter(new FileOutputStream("DOPOSoccer.log", true))) {
            pw.println("[" + LocalDateTime.now() + "] ERROR: " + exception.getMessage());
            exception.printStackTrace(pw);
            pw.println("--------------------------------------------------");
        } catch (Exception ignored) {
            // Evita lanzar excepción secundaria si falla el acceso al disco
        }
    }
}