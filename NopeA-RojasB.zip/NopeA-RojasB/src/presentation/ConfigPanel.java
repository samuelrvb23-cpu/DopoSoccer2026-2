package presentation;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

/**
 * Maqueta de Configuración del Juego y Mejora de Estadísticas.
 */
public class ConfigPanel extends JPanel {

    private final DOPOSoccerGUI gui;

    // Países y poderes según PDF
    private static final String[] COUNTRIES = {
        "Corea del Sur (Aura Azul - Daño 40)",
        "Camerún (Rayo - Daño 60)",
        "Nigeria (Tornado - Daño 40)",
        "Estados Unidos (Ilusión - Daño 30)"
    };

    private static final String[] CPU_PROFILES = {
        "Torpe", "Ofensiva", "Defensiva", "Experta"
    };

    private static final String[] RESOLUTIONS = {
        "Pequeña (850 x 540)",
        "Mediana (1024 x 640)",
        "Grande (1200 x 720)"
    };

    // Controles de configuración general
    private JComboBox<String> comboMode;
    private JComboBox<String> comboCpuProfile;
    private JComboBox<String> comboResolution;
    private JRadioButton radioByTime;
    private JRadioButton radioByGoals;
    private JSpinner spinnerTargetValue;

    // Controles Jugador 1 y Jugador 2
    private JComboBox<String> comboP1Country;
    private JComboBox<String> comboP2Country;

    // Puntos y estadísticas visuales (Speed, Jump, Kick, Survival)
    private int p1Points = 1500; // Puntos de demostración para probar mejoras en la maqueta
    private int p2Points = 1500;
    private final int[] p1Stats = {1, 1, 1, 1};
    private final int[] p1Costs = {500, 500, 500, 500};
    private final int[] p2Stats = {1, 1, 1, 1};
    private final int[] p2Costs = {500, 500, 500, 500};

    private JLabel lblP1Points;
    private JLabel lblP2Points;
    private final JLabel[] lblP1StatValues = new JLabel[4];
    private final JButton[] btnP1Upgrade = new JButton[4];
    private final JLabel[] lblP2StatValues = new JLabel[4];
    private final JButton[] btnP2Upgrade = new JButton[4];

    // Botones inferiores
    private JButton btnBack;
    private JButton btnStartMatch;

    public ConfigPanel(DOPOSoccerGUI gui) {
        this.gui = gui;
        prepareView();
        prepareController();
    }

    private void prepareView() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // 1. Panel Norte: Reglas del Partido y Resolución
        add(prepareMatchRulesPanel(), BorderLayout.NORTH);

        // 2. Panel Central: Selección de Personajes y Estadísticas (J1 vs J2)
        JPanel playersContainer = new JPanel(new GridLayout(1, 2, 15, 0));
        playersContainer.add(preparePlayerPanel(true));
        playersContainer.add(preparePlayerPanel(false));
        add(playersContainer, BorderLayout.CENTER);

        // 3. Panel Sur: Botones de navegación
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 5));
        btnBack = new JButton("Volver al Menú");
        btnStartMatch = new JButton("¡Iniciar Partido!");
        btnStartMatch.setFont(new Font("Arial", Font.BOLD, 16));
        btnStartMatch.setBackground(new Color(40, 167, 69));
        btnStartMatch.setForeground(Color.WHITE);

        bottomPanel.add(btnBack);
        bottomPanel.add(btnStartMatch);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private JPanel prepareMatchRulesPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 4, 12, 10));
        panel.setBorder(new CompoundBorder(
                new TitledBorder("Configuración General del Partido"),
                new EmptyBorder(8, 8, 8, 8)));

        comboMode = new JComboBox<>(new String[]{"Jugador vs Jugador", "Jugador vs Máquina"});
        comboCpuProfile = new JComboBox<>(CPU_PROFILES);
        comboCpuProfile.setEnabled(false);
        comboResolution = new JComboBox<>(RESOLUTIONS);
        comboResolution.setSelectedIndex(1);

        radioByTime = new JRadioButton("Por Tiempo (min)", true);
        radioByGoals = new JRadioButton("Por Goles (meta)");
        ButtonGroup groupType = new ButtonGroup();
        groupType.add(radioByTime);
        groupType.add(radioByGoals);

        spinnerTargetValue = new JSpinner(new SpinnerNumberModel(2, 1, 15, 1));

        panel.add(new JLabel("Modalidad:"));
        panel.add(comboMode);
        panel.add(new JLabel("Perfil Máquina (CPU):"));
        panel.add(comboCpuProfile);

        panel.add(new JLabel("Resolución Cancha:"));
        panel.add(comboResolution);

        JPanel typeRadioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        typeRadioPanel.add(radioByTime);
        typeRadioPanel.add(radioByGoals);
        panel.add(typeRadioPanel);

        JPanel targetPanel = new JPanel(new BorderLayout(5, 0));
        targetPanel.add(new JLabel("Valor (Min/Goles):"), BorderLayout.WEST);
        targetPanel.add(spinnerTargetValue, BorderLayout.CENTER);
        panel.add(targetPanel);

        return panel;
    }

    private JPanel preparePlayerPanel(boolean isPlayer1) {
        String title = isPlayer1 ? "Jugador 1 (Controles: W, A, S, D + E)" : "Jugador 2 (Controles: Flechas + Enter)";
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(new CompoundBorder(new TitledBorder(title), new EmptyBorder(10, 10, 10, 10)));

        // Selección de País
        JPanel topPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        JComboBox<String> comboCountry = new JComboBox<>(COUNTRIES);
        if (!isPlayer1) {
            comboCountry.setSelectedIndex(1);
            comboP2Country = comboCountry;
        } else {
            comboP1Country = comboCountry;
        }

        JLabel lblPoints = new JLabel("Puntos disponibles: 1500 pts");
        lblPoints.setFont(new Font("Arial", Font.BOLD, 14));
        lblPoints.setForeground(new Color(0, 102, 204));
        if (isPlayer1) lblP1Points = lblPoints;
        else lblP2Points = lblPoints;

        topPanel.add(comboCountry);
        topPanel.add(lblPoints);
        panel.add(topPanel, BorderLayout.NORTH);

        // Tabla de Estadísticas (Speed, Jump, Kick, Survival)
        String[] statNames = {
            "Speed (Velocidad)",
            "Jump (Altura Salto)",
            "Kick (Daño +10%/niv)",
            "Survival (Vida +10%/niv)"
        };

        JPanel statsGrid = new JPanel(new GridLayout(4, 3, 8, 12));
        statsGrid.setBorder(new TitledBorder("Mejora de Estadísticas (Máx. 10)"));

        for (int i = 0; i < 4; i++) {
            statsGrid.add(new JLabel(statNames[i]));
            JLabel lblVal = new JLabel("Nivel: 1 / 10", SwingConstants.CENTER);
            JButton btnUp = new JButton("Mejorar (500 pts)");

            if (isPlayer1) {
                lblP1StatValues[i] = lblVal;
                btnP1Upgrade[i] = btnUp;
            } else {
                lblP2StatValues[i] = lblVal;
                btnP2Upgrade[i] = btnUp;
            }

            statsGrid.add(lblVal);
            statsGrid.add(btnUp);
        }

        panel.add(statsGrid, BorderLayout.CENTER);
        return panel;
    }

    private void prepareController() {
        comboMode.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isVsMachine = comboMode.getSelectedIndex() == 1;
                comboCpuProfile.setEnabled(isVsMachine);
            }
        });

        // Oyentes para mejoras de estadísticas de Jugador 1 y Jugador 2
        for (int i = 0; i < 4; i++) {
            final int statIndex = i;
            btnP1Upgrade[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    upgradeStatAction(true, statIndex);
                }
            });
            btnP2Upgrade[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    upgradeStatAction(false, statIndex);
                }
            });
        }

        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gui.showScreen(DOPOSoccerGUI.MENU_VIEW);
            }
        });

        btnStartMatch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                launchMatchAction();
            }
        });
    }

    /**
     * Aplica la regla de duplicación de precio (500, 1000, 2000) del pdf
     */
    private void upgradeStatAction(boolean isP1, int index) {
        int[] stats = isP1 ? p1Stats : p2Stats;
        int[] costs = isP1 ? p1Costs : p2Costs;
        int availablePoints = isP1 ? p1Points : p2Points;

        if (stats[index] >= 10) {
            JOptionPane.showMessageDialog(this, "La estadística ya alcanzó el nivel máximo (10).",
                    "Nivel Máximo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        if (availablePoints < costs[index]) {
            JOptionPane.showMessageDialog(this,
                    "Puntos insuficientes. Necesitas " + costs[index] + " puntos.",
                    "No hay puntos suficientes", JOptionPane.WARNING_MESSAGE);
            return;
        }

        availablePoints -= costs[index];
        stats[index]++;
        costs[index] *= 2; // El precio se duplica respecto al anterior

        if (isP1) {
            p1Points = availablePoints;
            lblP1Points.setText("Puntos disponibles: " + p1Points + " pts");
            lblP1StatValues[index].setText("Nivel: " + stats[index] + " / 10");
            btnP1Upgrade[index].setText(stats[index] == 10 ? "MÁXIMO" : "Mejorar (" + costs[index] + " pts)");
        } else {
            p2Points = availablePoints;
            lblP2Points.setText("Puntos disponibles: " + p2Points + " pts");
            lblP2StatValues[index].setText("Nivel: " + stats[index] + " / 10");
            btnP2Upgrade[index].setText(stats[index] == 10 ? "MÁXIMO" : "Mejorar (" + costs[index] + " pts)");
        }
    }

    private void launchMatchAction() {
        String mode = (String) comboMode.getSelectedItem();
        String p1Country = ((String) comboP1Country.getSelectedItem()).split(" \\(")[0];
        String p2Country = ((String) comboP2Country.getSelectedItem()).split(" \\(")[0];
        boolean isByTime = radioByTime.isSelected();
        int targetVal = (Integer) spinnerTargetValue.getValue();

        Dimension res;
        int resIndex = comboResolution.getSelectedIndex();
        if (resIndex == 0) res = new Dimension(850, 540);
        else if (resIndex == 2) res = new Dimension(1200, 720);
        else res = new Dimension(1024, 640);

        gui.startConfiguredMatch(mode, p1Country, p2Country, isByTime, targetVal, res);
    }

    public void setSelectedMode(String mode) {
        comboMode.setSelectedItem(mode);
        comboCpuProfile.setEnabled("Jugador vs Máquina".equals(mode));
    }

    /**
     * Devuelve el perfil de IA seleccionado para el Jugador 2 / CPU.
     */
    public String getSelectedCpuProfile() {
        return (String) comboCpuProfile.getSelectedItem();
    }

    public void addMatchRewardPoints(boolean p1Won) {
        // Regla del pdf: +100 puntos al ganador y +25 al perdedor
        p1Points += p1Won ? 100 : 25;
        p2Points += p1Won ? 25 : 100;
        lblP1Points.setText("Puntos disponibles: " + p1Points + " pts");
        lblP2Points.setText("Puntos disponibles: " + p2Points + " pts");
    }
    public int[] getP1Stats() {
        return p1Stats;
    }

    public int[] getP2Stats() {
        return p2Stats;
    }
}