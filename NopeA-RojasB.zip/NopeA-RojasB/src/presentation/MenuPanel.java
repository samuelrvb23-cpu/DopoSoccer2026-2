package presentation;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * Pantalla de inicio de DOPOSoccer.
 */
public class MenuPanel extends JPanel {

    private final DOPOSoccerGUI gui;
    private JButton btnPvP;
    private JButton btnPvM;
    private JButton btnOpen;
    private JButton btnExit;

    public MenuPanel(DOPOSoccerGUI gui) {
        this.gui = gui;
        prepareView();
        prepareController();
    }

    private void prepareView() {
        setLayout(new BorderLayout());
        setBackground(new Color(20, 35, 60));

        // Título central
        JPanel headerPanel = new JPanel(new GridLayout(2, 1));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(new EmptyBorder(60, 20, 30, 20));

        JLabel lblTitle = new JLabel("DOPOSOCCER 2026-2", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 52));
        lblTitle.setForeground(new Color(255, 215, 0));

        JLabel lblSubtitle = new JLabel("Fútbol Arcade 2D", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Arial", Font.PLAIN, 20));
        lblSubtitle.setForeground(Color.WHITE);

        headerPanel.add(lblTitle);
        headerPanel.add(lblSubtitle);
        add(headerPanel, BorderLayout.NORTH);

        // Botonera central usando GridLayout 
        JPanel buttonsPanel = new JPanel(new GridLayout(4, 1, 15, 15));
        buttonsPanel.setOpaque(false);
        buttonsPanel.setBorder(new EmptyBorder(20, 320, 80, 320));

        btnPvP = createStyledButton("Jugador vs Jugador (Local)");
        btnPvM = createStyledButton("Jugador vs Máquina (CPU)");
        btnOpen = createStyledButton("Abrir Partida Guardada");
        btnExit = createStyledButton("Salir del Juego");

        buttonsPanel.add(btnPvP);
        buttonsPanel.add(btnPvM);
        buttonsPanel.add(btnOpen);
        buttonsPanel.add(btnExit);

        add(buttonsPanel, BorderLayout.CENTER);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setFocusPainted(false);
        button.setBackground(new Color(40, 167, 69));
        button.setForeground(Color.WHITE);
        return button;
    }

    private void prepareController() {
        btnPvP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gui.getConfigPanel().setSelectedMode("Jugador vs Jugador");
                gui.showScreen(DOPOSoccerGUI.CONFIG_VIEW);
            }
        });

        btnPvM.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gui.getConfigPanel().setSelectedMode("Jugador vs Máquina");
                gui.showScreen(DOPOSoccerGUI.CONFIG_VIEW);
            }
        });

        btnOpen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gui.openFileAction();
            }
        });

        btnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gui.exitApplicationAction();
            }
        });
    }
}