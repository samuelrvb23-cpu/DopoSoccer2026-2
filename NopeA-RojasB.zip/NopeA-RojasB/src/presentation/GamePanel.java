package presentation;

import domain.AIProfile;
import domain.Ball;
import domain.DOPOSoccerException;
import domain.DOPOSoccerFacade;
import domain.MatchSaveData;
import domain.Player;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Pantalla del partido (HUD superior y lienzo 2D de la cancha).
 */
public class GamePanel extends JPanel {

    private final DOPOSoccerGUI gui;
    private DOPOSoccerFacade facade = new DOPOSoccerFacade();

    // Componentes del HUD Superior
    private JLabel lblP1Name;
    private JLabel lblP2Name;
    private JLabel lblScore;
    private JLabel lblTimerOrGoal;
    private JProgressBar barP1Life;
    private JProgressBar barP1Power;
    private JProgressBar barP2Life;
    private JProgressBar barP2Power;

    // Botones de control del partido
    private JButton btnPause;
    private JButton btnEndMatch;
    private CourtCanvas courtCanvas;

    // Timers para el bucle de renderizado (60 FPS) y cronómetro (1 s)
    private Timer gameLoopTimer;
    private Timer secondTimer;
    private boolean isPaused = false;

    // Control de modalidad IA vs Jugador
    private boolean vsMachine = false;
    private String currentCpuAction = AIProfile.ACTION_IDLE;
    private int aiDecisionCooldown = 0;

    private final Set<Integer> pressedKeys = new HashSet<>();
    private final List<Ball> fakeBalls = new ArrayList<>();
    private int fakeBallsTimer = 0;

    // Reglas del partido actual
    private boolean isByTime = true;
    private int remainingSeconds = 120;
    private int goalsTarget = 5;

    /**
     * Inicializa el panel de juego, construye su vista y registra sus controles.
     */
    public GamePanel(DOPOSoccerGUI gui) {
        this.gui = gui;
        setFocusable(true);
        prepareView();
        prepareController();
    }

    /**
     * Construye el marcador superior (HUD) y agrega el lienzo de la cancha.
     */
    private void prepareView() {
        setLayout(new BorderLayout());

        JPanel hudPanel = new JPanel(new BorderLayout(15, 5));
        hudPanel.setBackground(new Color(25, 30, 45));
        hudPanel.setBorder(new EmptyBorder(10, 20, 10, 20));

        // HUD Jugador 1 (Izquierda)
        JPanel p1Hud = new JPanel(new GridLayout(3, 1, 2, 4));
        p1Hud.setOpaque(false);
        lblP1Name = new JLabel("J1: Corea del Sur");
        lblP1Name.setForeground(Color.WHITE);
        lblP1Name.setFont(new Font("Arial", Font.BOLD, 14));
        barP1Life = createBar(new Color(40, 200, 80), "Vida: 100%");
        barP1Power = createBar(new Color(0, 180, 255), "Poder: 0%");
        p1Hud.add(lblP1Name);
        p1Hud.add(barP1Life);
        p1Hud.add(barP1Power);

        // HUD Central (Marcador, Tiempo y Botones)
        JPanel centerHud = new JPanel(new GridLayout(3, 1, 2, 2));
        centerHud.setOpaque(false);
        lblScore = new JLabel("0 - 0", SwingConstants.CENTER);
        lblScore.setFont(new Font("Arial", Font.BOLD, 32));
        lblScore.setForeground(new Color(255, 215, 0));

        lblTimerOrGoal = new JLabel("Tiempo: 02:00", SwingConstants.CENTER);
        lblTimerOrGoal.setFont(new Font("Arial", Font.BOLD, 15));
        lblTimerOrGoal.setForeground(Color.WHITE);

        JPanel controlButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        controlButtons.setOpaque(false);
        btnPause = new JButton("Pausar");
        btnEndMatch = new JButton("Terminar");
        btnPause.setFocusable(false);
        btnEndMatch.setFocusable(false);
        controlButtons.add(btnPause);
        controlButtons.add(btnEndMatch);

        centerHud.add(lblScore);
        centerHud.add(lblTimerOrGoal);
        centerHud.add(controlButtons);

        // HUD Jugador 2 (Derecha)
        JPanel p2Hud = new JPanel(new GridLayout(3, 1, 2, 4));
        p2Hud.setOpaque(false);
        lblP2Name = new JLabel("J2: Camerún", SwingConstants.RIGHT);
        lblP2Name.setForeground(Color.WHITE);
        lblP2Name.setFont(new Font("Arial", Font.BOLD, 14));
        barP2Life = createBar(new Color(40, 200, 80), "Vida: 100%");
        barP2Power = createBar(new Color(0, 180, 255), "Poder: 0%");
        p2Hud.add(lblP2Name);
        p2Hud.add(barP2Life);
        p2Hud.add(barP2Power);

        hudPanel.add(p1Hud, BorderLayout.WEST);
        hudPanel.add(centerHud, BorderLayout.CENTER);
        hudPanel.add(p2Hud, BorderLayout.EAST);

        add(hudPanel, BorderLayout.NORTH);

        courtCanvas = new CourtCanvas();
        add(courtCanvas, BorderLayout.CENTER);
    }

    /**
     * Crea y configura una barra de progreso para mostrar vida o poder.
     */
    private JProgressBar createBar(Color color, String text) {
        JProgressBar bar = new JProgressBar(0, 100);
        bar.setValue(text.startsWith("Vida") ? 100 : 0);
        bar.setStringPainted(true);
        bar.setString(text);
        bar.setForeground(color);
        bar.setPreferredSize(new Dimension(240, 18));
        return bar;
    }

    /**
     * Configura los oyentes de botones, teclado y los temporizadores del partido.
     */
    private void prepareController() {
        btnPause.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                togglePauseAction();
            }
        });

        btnEndMatch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                finishMatchAction("Partido terminado manualmente por los jugadores.");
            }
        });

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pressedKeys.add(e.getKeyCode());
                handleSinglePressActions(e.getKeyCode());
            }

            @Override
            public void keyReleased(KeyEvent e) {
                pressedKeys.remove(e.getKeyCode());
            }
        });

        gameLoopTimer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isPaused) {
                    updateSimulation();
                    syncHud();
                    courtCanvas.repaint();
                }
            }
        });

        secondTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isPaused) {
                    onSecondElapsed();
                }
            }
        });
    }
    
    /**
     * Prepara los datos iniciales y arranca un nuevo partido con la configuración elegida.
     */
    public void setupMatch(String mode, String p1Country, String p2Country, boolean byTime, int targetValue) {
        this.isByTime = byTime;
        this.isPaused = false;
        this.vsMachine = "Jugador vs Máquina".equals(mode);
        this.currentCpuAction = AIProfile.ACTION_IDLE;
        this.aiDecisionCooldown = 0;
        this.pressedKeys.clear();
        this.fakeBalls.clear();
        this.fakeBallsTimer = 0;

        String cpuProfile = (gui != null && gui.getConfigPanel() != null)
                ? gui.getConfigPanel().getSelectedCpuProfile()
                : "Experta";

        try {
            facade.configureMatch(p1Country, p2Country);
            facade.setMatchMode(this.vsMachine, cpuProfile);
        } catch (DOPOSoccerException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error de Configuración", JOptionPane.ERROR_MESSAGE);
        }
        applyConfiguredStats(facade.getPlayer1(), gui.getConfigPanel().getP1Stats());
        applyConfiguredStats(facade.getPlayer2(), gui.getConfigPanel().getP2Stats());
        lblP1Name.setText("J1: " + p1Country);
        lblP2Name.setText(vsMachine ? "CPU (" + cpuProfile + "): " + p2Country : "J2: " + p2Country);
        lblScore.setText("0 - 0");

        if (isByTime) {
            remainingSeconds = targetValue * 60;
            updateTimerLabel();
        } else {
            goalsTarget = targetValue;
            lblTimerOrGoal.setText("Meta: Primero en anotar " + goalsTarget + " goles");
        }

        resetPositionsAfterGoal();
        syncHud();
        gameLoopTimer.start();
        secondTimer.start();
    }
    private void applyConfiguredStats(Player player, int[] levels) {
        if (player != null && levels != null && levels.length == 4) {
            player.getStats().setLevels(levels[0], levels[1], levels[2], levels[3]);
            player.resetForNewMatch();
        }
    }

    /**
     * Detiene los temporizadores del bucle gráfico y del cronómetro.
     */
    public void stopMatchLoop() {
        gameLoopTimer.stop();
        secondTimer.stop();
    }

    /**
     * Pausa o reanuda el partido y actualiza el texto del botón.
     */
    private void togglePauseAction() {
        isPaused = !isPaused;
        btnPause.setText(isPaused ? "Reanudar" : "Pausar");
        courtCanvas.repaint();
        requestFocusInWindow();
    }

    /**
     * Ejecuta las acciones instantáneas de activar poder o patear al presionar una tecla.
     */
    private void handleSinglePressActions(int keyCode) {
        if (!isPaused) {
            Player p1 = facade.getPlayer1();
            Player p2 = facade.getPlayer2();

            if (keyCode == KeyEvent.VK_E && p1 != null) {
                p1.activatePower();
            } else if (keyCode == KeyEvent.VK_S) {
                executeKick(p1, p2);
            } else if (!vsMachine) {
                if (keyCode == KeyEvent.VK_ENTER && p2 != null) {
                    p2.activatePower();
                } else if (keyCode == KeyEvent.VK_DOWN) {
                    executeKick(p2, p1);
                }
            }
        }
    }

    /**
     * Aplica las acciones decididas por la IA para el Jugador 2 (CPU).
     */
    private void applyCpuControls(Player p2, Player p1, double minX, double maxX, int groundY) {
        if (p2 == null) {
            return;
        }
        if (aiDecisionCooldown <= 0) {
            currentCpuAction = facade.decideCpuAction();
            aiDecisionCooldown = 6;
        } else {
            aiDecisionCooldown--;
        }

        if (AIProfile.ACTION_MOVE_LEFT.equals(currentCpuAction)) {
            p2.moveLeft(minX);
        } else if (AIProfile.ACTION_MOVE_RIGHT.equals(currentCpuAction)) {
            p2.moveRight(maxX);
        } else if (AIProfile.ACTION_JUMP.equals(currentCpuAction)) {
            p2.jump(groundY);
            currentCpuAction = AIProfile.ACTION_IDLE;
        } else if (AIProfile.ACTION_POWER.equals(currentCpuAction)) {
            p2.activatePower();
            currentCpuAction = AIProfile.ACTION_IDLE;
        } else if (AIProfile.ACTION_KICK.equals(currentCpuAction)) {
            executeKick(p2, p1);
            currentCpuAction = AIProfile.ACTION_IDLE;
        }
    }

    /**
     * Ejecuta una patada: si toca el balón lo impulsa; si no, daña al rival si está al alcance.
     */
    private void executeKick(Player active, Player opponent) {
        Ball ball = facade.getBall();
        if (active != null && active.canAct()) {
            active.triggerKickAnimation();

            double px = active.getPosX() + 25.0;
            double py = active.getPosY() - 30.0;
            boolean touchedBall = (ball != null && Math.hypot(px - ball.getPosX(), py - ball.getPosY()) <= 75.0);

            if (touchedBall) {
                if (active.hasActiveAura() && active.getCharacter() != null) {
                    firePowerShot(active, opponent, ball);
                } else if (!ball.hasActivePowerShot()) {
                    ball.applyNormalKick(active.isFacingRight(), active);
                }
            } else if (opponent != null
                    && Math.abs(active.getPosX() - opponent.getPosX()) < 65.0
                    && Math.abs(active.getPosY() - opponent.getPosY()) < 50.0) {
                double kickDamage = Player.BASE_KICK_DAMAGE * active.getStats().getKickMultiplier();
                opponent.receiveDamage(kickDamage);
            }
        }
    }

    /**
     * Dispara el tiro de poder del personaje y crea balones falsos si el poder los requiere.
     */
    private void firePowerShot(Player shooter, Player rival, Ball ball) {
        ball.setPosY(Math.min(ball.getPosY(), shooter.getPosY() - 38.0));
        shooter.getCharacter().triggerPowerShot(shooter, rival, ball);

        fakeBalls.clear();
        fakeBalls.addAll(shooter.getCharacter().createExtraBalls(ball.getPosX(), ball.getPosY(), shooter.isFacingRight()));
        if (!fakeBalls.isEmpty()) {
            fakeBallsTimer = 150;
        }
    }

    /**
     * Se ejecuta cada segundo para cargar las barras de poder y descontar el tiempo del partido.
     */
    private void onSecondElapsed() {
        Player p1 = facade.getPlayer1();
        Player p2 = facade.getPlayer2();
        if (p1 != null) {
            p1.chargePowerBar(10.0);
        }
        if (p2 != null) {
            p2.chargePowerBar(10.0);
        }
        syncHud();

        if (isByTime) {
            if (remainingSeconds > 0) {
                remainingSeconds--;
                updateTimerLabel();
            } else if (p1 != null && p2 != null) {
                if (p1.getGoals() != p2.getGoals()) {
                    finishMatchAction("¡Tiempo reglamentario finalizado!");
                } else {
                    lblTimerOrGoal.setText("¡MUERTE SÚBITA! (Gol gana)");
                }
            }
        }
    }

    /**
     * Sincroniza las barras visuales de ambos jugadores con su estado actual en el dominio.
     */
    private void syncHud() {
        updatePlayerHud(facade.getPlayer1(), barP1Life, barP1Power);
        updatePlayerHud(facade.getPlayer2(), barP2Life, barP2Power);
    }

    /**
     * Actualiza los valores y textos de las barras de vida y poder de un jugador.
     */
    private void updatePlayerHud(Player player, JProgressBar lifeBar, JProgressBar powerBar) {
        if (player != null) {
            int lifePct = player.getLifePercentage();
            int curLife = (int) Math.round(player.getCurrentLife());
            int maxLife = (int) Math.round(player.getStats().getMaxLife());
            lifeBar.setValue(lifePct);
            lifeBar.setString("Vida: " + curLife + " / " + maxLife);

            int powPct = (int) Math.round(player.getPowerBar());
            powerBar.setValue(powPct);
            powerBar.setString(player.hasActiveAura() ? "Poder: " + powPct + "% (Aura Activa)" : "Poder: " + powPct + "%");
        }
    }

    /**
     * Muestra el tiempo restante con formato MM:SS en el marcador central.
     */
    private void updateTimerLabel() {
        int min = remainingSeconds / 60;
        int sec = remainingSeconds % 60;
        lblTimerOrGoal.setText(String.format("Tiempo: %02d:%02d", min, sec));
    }

    /**
     * Actualiza en cada fotograma el movimiento, la física, las colisiones y los goles.
     */
    private void updateSimulation() {
        int w = Math.max(800, courtCanvas.getWidth());
        int groundY = Math.max(350, courtCanvas.getHeight() - 60);
        double minX = 60.0;
        double maxX = w - 110.0;

        Player p1 = facade.getPlayer1();
        Player p2 = facade.getPlayer2();
        Ball ball = facade.getBall();

        if (p1 != null && p2 != null && ball != null) {
            // 1. Controles de teclado / IA
            if (pressedKeys.contains(KeyEvent.VK_A)) p1.moveLeft(minX);
            if (pressedKeys.contains(KeyEvent.VK_D)) p1.moveRight(maxX);
            if (pressedKeys.contains(KeyEvent.VK_W)) p1.jump(groundY);

            if (vsMachine || facade.isVsMachine()) {
                applyCpuControls(p2, p1, minX, maxX, groundY);
            } else {
                if (pressedKeys.contains(KeyEvent.VK_LEFT)) p2.moveLeft(minX);
                if (pressedKeys.contains(KeyEvent.VK_RIGHT)) p2.moveRight(maxX);
                if (pressedKeys.contains(KeyEvent.VK_UP)) p2.jump(groundY);
            }

            // 2. Gravedad, colisión entre jugadores y temporizadores internos
            p1.applyGravity(groundY);
            p2.applyGravity(groundY);
            p1.resolveCollisionWith(p2, minX, maxX);
            p1.update();
            p2.update();

            // 3. Física del balón y trayectorias polimórficas de tiros de poder
            ball.updatePhysics();
            if (ball.hasActivePowerShot()) {
                ball.getActivePowerShot().updatePowerBallPhysics(ball, groundY);
                if (Math.abs(ball.getVelX()) < 2.0) {
                    ball.clearPowerShot();
                }
            }
            if (ball.getPosY() >= groundY - Ball.RADIUS && ball.getVelY() > 0) {
                ball.bounceVertical(groundY - Ball.RADIUS);
                ball.setVelX(ball.getVelX() * 0.98);
            }
            if (ball.getPosY() < 20.0) {
                ball.bounceVertical(20.0);
            }

            // 4. Balones falsos (poder Ilusión)
            if (fakeBallsTimer > 0) {
                fakeBallsTimer--;
                for (Ball fake : fakeBalls) {
                    fake.updatePhysics();
                    if (fake.getPosY() >= groundY - Ball.RADIUS && fake.getVelY() > 0) {
                        fake.bounceVertical(groundY - Ball.RADIUS);
                    }
                    if (fake.getPosX() < 20.0) {
                        fake.bounceHorizontal(20.0);
                    } else if (fake.getPosX() > w - 20.0) {
                        fake.bounceHorizontal(w - 20.0);
                    }
                }
                if (fakeBallsTimer == 0) {
                    fakeBalls.clear();
                }
            }

            // 5. Colisión de cada jugador con el balón
            handlePlayerBallCollision(p1, p2, ball, minX, maxX, groundY);
            handlePlayerBallCollision(p2, p1, ball, minX, maxX, groundY);

            // 6. Verificación de goles, rebote en travesaño y paredes laterales
            int goalTop = groundY - 130;
            double bx = ball.getPosX();
            double by = ball.getPosY();
            boolean inLeftGoalX = bx <= 55.0;
            boolean inRightGoalX = bx >= w - 55.0;

            if (inLeftGoalX && by >= goalTop + Ball.RADIUS) {
                registerGoal(p2, p1);
            } else if (inRightGoalX && by >= goalTop + Ball.RADIUS) {
                registerGoal(p1, p2);
            } else if ((inLeftGoalX || inRightGoalX) && Math.abs(by - goalTop) <= Ball.RADIUS) {
                ball.bounceVertical(goalTop - Ball.RADIUS);
                double reboundX = Math.abs(ball.getVelX()) * 0.8 + 2.0;
                ball.setVelX(inLeftGoalX ? reboundX : -reboundX);
                ball.clearPowerShot();
            } else if (bx < 20.0) {
                ball.bounceHorizontal(20.0);
                ball.clearPowerShot();
            } else if (bx > w - 20.0) {
                ball.bounceHorizontal(w - 20.0);
                ball.clearPowerShot();
            }
        }
    }

    /**
     * Resuelve el contacto entre un jugador y el balón (impacto de poder rival, poder propio o conducción).
     */
    private void handlePlayerBallCollision(Player me, Player rival, Ball ball, double minX, double maxX, int groundY) {
        double px = me.getPosX() + 25.0;
        double py = me.getPosY() - 35.0;
        double hitRadius = ball.hasActivePowerShot() ? 58.0 : 42.0;

        if (Math.hypot(px - ball.getPosX(), py - ball.getPosY()) < hitRadius) {
            if (ball.hasActivePowerShot() && ball.getLastShooter() == rival) {
                ball.getActivePowerShot().onPowerShotHitOpponent(rival, me, ball);
                me.clampPositionX(minX, maxX);
                ball.setVelX(-ball.getVelX() * 0.4);
                ball.setVelY(-7.0);
            } else if (me.hasActiveAura() && me.getCharacter() != null) {
                firePowerShot(me, rival, ball);
            } else if (!ball.hasActivePowerShot()) {
                ball.applyBodyTouch(px, py, me.isInAir(groundY), me);
            }
        }
    }

    /**
     * Registra un gol, carga 25% de poder a quien lo recibió y verifica si el partido terminó.
     */
    private void registerGoal(Player scorer, Player conceded) {
        scorer.scoreGoal();
        conceded.onGoalConceded();

        Player p1 = facade.getPlayer1();
        Player p2 = facade.getPlayer2();
        lblScore.setText(p1.getGoals() + " - " + p2.getGoals());

        fakeBalls.clear();
        fakeBallsTimer = 0;
        resetPositionsAfterGoal();
        syncHud();

        if (!isByTime && (p1.getGoals() >= goalsTarget || p2.getGoals() >= goalsTarget)) {
            finishMatchAction("¡Se alcanzó la meta de goles!");
        } else if (isByTime && remainingSeconds == 0) {
            finishMatchAction("¡Gol de Oro en Muerte Súbita!");
        }
    }

    /**
     * Ubica a los jugadores y al balón en sus posiciones iniciales tras cada gol.
     */
    private void resetPositionsAfterGoal() {
        int w = Math.max(850, getWidth());
        int groundY = Math.max(350, getHeight() - 150);

        if (facade.getPlayer1() != null) {
            facade.getPlayer1().resetPosition(w * 0.22, groundY - 80);
        }
        if (facade.getPlayer2() != null) {
            facade.getPlayer2().resetPosition(w * 0.72, groundY - 80);
        }
        if (facade.getBall() != null) {
            facade.getBall().resetPosition(w * 0.50, 120);
        }
    }
    /**
     * Exporta el estado actual de la fachada y las reglas del partido para guardar en disco.
     */
    public MatchSaveData exportMatchSaveData() {
        Player p1 = facade.getPlayer1();
        Player p2 = facade.getPlayer2();
        String c1 = (p1 != null && p1.getCharacter() != null) ? p1.getCharacter().getCountryName() : "Corea del Sur";
        String c2 = (p2 != null && p2.getCharacter() != null) ? p2.getCharacter().getCountryName() : "Camerún";
        String mode = (vsMachine || facade.isVsMachine()) ? "Jugador vs Máquina" : "Jugador vs Jugador";
        String cpuProf = (gui != null && gui.getConfigPanel() != null)
                ? gui.getConfigPanel().getSelectedCpuProfile()
                : "Experta";

        return new MatchSaveData(
                facade, isByTime, remainingSeconds, goalsTarget, mode, cpuProf, c1, c2
        );
    }

    /**
     * Restaura una partida guardada y reanuda los temporizadores del partido.
     */
    public void loadMatchSaveData(MatchSaveData data) {
        stopMatchLoop();
        this.facade = data.facade;
        this.isByTime = data.isByTime;
        this.remainingSeconds = data.remainingSeconds;
        this.goalsTarget = data.goalsTarget;
        this.vsMachine = "Jugador vs Máquina".equals(data.mode) || facade.isVsMachine();
        this.currentCpuAction = AIProfile.ACTION_IDLE;
        this.aiDecisionCooldown = 0;
        this.isPaused = false;
        this.pressedKeys.clear();
        this.fakeBalls.clear();
        this.fakeBallsTimer = 0;

        lblP1Name.setText("J1: " + data.p1Country);
        lblP2Name.setText(vsMachine ? "CPU (" + data.cpuProfile + "): " + data.p2Country : "J2: " + data.p2Country);

        Player p1 = facade.getPlayer1();
        Player p2 = facade.getPlayer2();
        int g1 = (p1 != null) ? p1.getGoals() : 0;
        int g2 = (p2 != null) ? p2.getGoals() : 0;
        lblScore.setText(g1 + " - " + g2);

        if (isByTime) {
            updateTimerLabel();
        } else {
            lblTimerOrGoal.setText("Meta: Primero en anotar " + goalsTarget + " goles");
        }

        syncHud();
        courtCanvas.repaint();
        gameLoopTimer.start();
        secondTimer.start();
    }
    
    /**
     * Termina el partido, asigna los puntos de recompensa, muestra el resumen y vuelve a configuración.
     */
    private void finishMatchAction(String reason) {
        stopMatchLoop();
        Player p1 = facade.getPlayer1();
        Player p2 = facade.getPlayer2();
        int g1 = (p1 != null) ? p1.getGoals() : 0;
        int g2 = (p2 != null) ? p2.getGoals() : 0;
        String c1 = (p1 != null && p1.getCharacter() != null) ? p1.getCharacter().getCountryName() : "Jugador 1";
        String c2 = (p2 != null && p2.getCharacter() != null) ? p2.getCharacter().getCountryName() : "Jugador 2";

        boolean p1Won = g1 >= g2;
        String winner = (g1 == g2) ? "Empate Técnico"
                : (p1Won ? "Jugador 1 (" + c1 + ")" : (vsMachine ? "CPU (" + c2 + ")" : "Jugador 2 (" + c2 + ")"));

        gui.getConfigPanel().addMatchRewardPoints(p1Won);

        JOptionPane.showMessageDialog(this,
                reason + "\n\n" +
                "Marcador Final: " + g1 + " - " + g2 + "\n" +
                "Ganador: " + winner + "\n\n" +
                "Puntos otorgados:\n" +
                "• Ganador: +100 puntos\n" +
                "• Perdedor: +25 puntos",
                "Fin del Partido",
                JOptionPane.INFORMATION_MESSAGE);

        gui.showScreen(DOPOSoccerGUI.CONFIG_VIEW);
    }

    /**
     * Lienzo interno encargado de dibujar la cancha, arcos, jugadores, auras y balones.
     */
    private class CourtCanvas extends JPanel {

        /**
         * Dibuja el estadio, los arcos, los jugadores, los balones y la pantalla de pausa.
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int groundY = h - 60;

            // Fondo de estadio y césped
            g2.setColor(new Color(135, 206, 235));
            g2.fillRect(0, 0, w, groundY);
            g2.setColor(new Color(46, 139, 87));
            g2.fillRect(0, groundY, w, 60);

            // Línea central y arcos
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(3));
            g2.drawLine(w / 2, groundY, w / 2, groundY + 60);
            int goalHeight = 130;
            g2.drawRect(10, groundY - goalHeight, 45, goalHeight);
            g2.drawRect(w - 55, groundY - goalHeight, 45, goalHeight);

            // Jugadores
            drawCharacter(g2, facade.getPlayer1(), new Color(30, 144, 255));
            drawCharacter(g2, facade.getPlayer2(), new Color(220, 53, 69));

            // Balones falsos y balón real
            for (Ball fake : fakeBalls) {
                drawBall(g2, fake);
            }
            if (facade.getBall() != null) {
                drawBall(g2, facade.getBall());
            }

            if (isPaused) {
                g2.setColor(new Color(0, 0, 0, 150));
                g2.fillRect(0, 0, w, h);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 40));
                g2.drawString("JUEGO EN PAUSA", w / 2 - 170, h / 2);
            }
        }

        /**
         * Dibuja un balón y su resplandor si lleva un tiro de poder visible.
         */
        private void drawBall(Graphics2D g2, Ball ball) {
            int bx = (int) ball.getPosX();
            int by = (int) ball.getPosY();

            // Si hay balones falsos activos (Ilusión), oculta el aura para que los 8 balones sean idénticos
            if (ball.hasActivePowerShot() && fakeBalls.isEmpty()) {
                Color c = new Color(ball.getActivePowerShot().getPowerColorRGB());
                g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 185));
                g2.fillOval(bx - 24, by - 24, 48, 48);
            }

            g2.setColor(Color.WHITE);
            g2.fillOval(bx - 14, by - 14, 28, 28);
            g2.setColor(Color.BLACK);
            g2.drawOval(bx - 14, by - 14, 28, 28);
        }

        /**
         * Dibuja un jugador con su aura, animación de patada, nombre de país y estado activo.
         */
        private void drawCharacter(Graphics2D g2, Player player, Color color) {
            if (player != null) {
                int x = (int) player.getPosX();
                int y = (int) player.getPosY();
                String country = (player.getCharacter() != null) ? player.getCharacter().getCountryName() : "";
                String effect = player.getActiveEffect();

                if (player.hasActiveAura()) {
                    g2.setColor(new Color(255, 215, 0, 140));
                    g2.fillOval(x - 12, y - 82, 74, 90);
                }

                if (!Player.EFFECT_NONE.equals(effect)) {
                    g2.setColor(new Color(180, 0, 255, 110));
                    g2.fillOval(x - 8, y - 75, 66, 80);
                }

                g2.setColor(color);
                g2.fillOval(x, y - 65, 50, 50);

                g2.setColor(Color.DARK_GRAY);
                g2.fillRoundRect(x + 10, y - 15, 30, 15, 8, 8);

                if (player.isKicking()) {
                    g2.setColor(Color.YELLOW);
                    int footX = player.isFacingRight() ? x + 38 : x - 12;
                    g2.fillRect(footX, y - 18, 24, 12);
                }

                g2.setColor(Color.BLACK);
                g2.setFont(new Font("Arial", Font.BOLD, 12));
                g2.drawString(country, x - 5, y - 72);

                if (player.isStunned()) {
                    g2.setColor(Color.RED);
                    g2.drawString("¡ATURDIDO!", x - 10, y - 88);
                } else if (!Player.EFFECT_NONE.equals(effect)) {
                    g2.setColor(new Color(128, 0, 128));
                    g2.drawString("¡" + effect + "!", x - 10, y - 88);
                }
            }
        }
    }
    
}